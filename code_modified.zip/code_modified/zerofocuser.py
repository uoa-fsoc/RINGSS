#Notes:
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python zerofocuser.py'
    #This script is to be used to set the foucser to its zero postion, allowing maximum steps in both directions

#Import libraries
from alpaca.focuser import Focuser

F = Focuser('localhost:11111', 0) #Set qfocuser device path
F.Connect() #Connect to qfocuser

zero_position = int(F.MaxStep / 2) #Find zero postion (half of max steps to allow equal movement both ways)
F.Move(zero_position)

F.Disconnect() #Disconnect from qfocuser