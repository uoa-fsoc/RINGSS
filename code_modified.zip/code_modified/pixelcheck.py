#Notes:
    #This script is a modified version of the already modified cube2.py script, which just extracts the ring radius and width
    #This script runs continously, use "space" to stop it
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python pixelcheck.py'

#Import libraries
from astropy.io import fits
import numpy as np
import sys
import os
import glob
import re
import time
import keyboard

#Constants
call_interval = 5 #s

def compute_ring_dimensions(data_cube): #Reduced version of Tokovinin's Moments function, just perfroms required calculations for ring radius and width
    # print("inside Moments()")
    nz, ny, nx = data_cube.shape  # 2000 64 64

    nstart = 50  # initial average of first 50 frames
    imav = np.average(data_cube[0:nstart], axis=0)  # average nstart frames

    i = np.indices((nx, nx))  # to create xx and yy vectors
    yy = i[0] - nx / 2
    xx = i[1] - nx / 2

    r = np.sqrt(np.square(xx) + np.square(yy))  # distance from center: plt.imshow(xx, cmap='Greys')
    phi = np.arctan2(yy, xx)  # 2D array of phase # plt.imshow(phi, cmap='Greys')

    # ## Prepare initial wide masks
    m = 20  # max order of angular signals
    nsect = 8  # number of sectors for radius calculation
    rwt = np.zeros((nsect, nx, nx))  # for radius calculation
    fwt = np.zeros((nsect, nx, nx))  # fluxes in the sectors
    sect = 2. * np.pi / nsect  # sector width in radians

    for j in range(0, nsect):
        sector = (phi >= (sect * (j - nsect / 2))) & (phi < (sect * (j + 1 - nsect / 2)))
        fwt[j] = sector
        rwt[j] = sector * r

    test = np.zeros((nx, nx))  # test correctness of radial masks
    for j in range(0, nsect):
        test += rwt[j] * (j + 1)

    phisect = sect * (np.arange(nsect, dtype=float) - nsect / 2 + 0.5)  # sector angles
    xsect, ysect = np.cos(phisect), np.sin(phisect)

    backgr = np.median([imav[:, 0], imav[:, nx - 1]])  # left and right columns,  scalar
    tmp = imav - backgr

    itot = np.sum(tmp)  # total flux and centroids
    xc = np.sum(tmp * xx) / itot
    yc = np.sum(tmp * yy) / itot

    imavcent = np.roll(tmp, (int(-xc), int(-yc)), (1, 0))  # crude shift by integer pixel number

    radii = np.zeros(nsect)  # preliminary radii of the sectors, in pixels
    for j in range(0, nsect):
        radii[j] = np.sum(imavcent * rwt[j]) / np.sum(imavcent * fwt[j])

    dx1 = np.sum(radii * xsect) / nsect * 2.3  # accurate x-shift
    dy1 = np.sum(radii * ysect) / nsect * 2.3  # accurate y-shift

    xc += dx1  # more accurate ring center
    yc += dy1

    # FFT sub-pixel shift by -dx1,-dy1
    arg = 2 * np.pi * (dx1 * xx + dy1 * yy) / nx
    imavcent = np.fft.ifft2(np.fft.fft2(imavcent) * np.fft.fftshift(np.cos(arg) + np.sin(arg) * 1j)).real

    # re-compute radii to check the centering, should be similar
    for j in range(0, nsect):
        radii[j] = np.sum(imavcent * rwt[j]) / np.sum(imavcent * fwt[j])
    radpix = np.sum(radii) / nsect

    # Threshold the image at 0.1*max to find the ring width
    tmp = (imavcent - 0.1 * np.max(imavcent))
    tmp *= (tmp > 0)  # plt.imshow(tmp, cmap='Greys')
    radvar = np.sum(tmp * (r - radpix) ** 2) / np.sum(tmp)
    rwidth = pow(radvar, 0.5) * 2.35
    # print("Ring width [pix]: ",rwidth)

    backgr += np.median(imavcent * (r > 1.5 * radpix))  # outside-ring pixels for refined background estimate

    drhopix = 1.5 * rwidth  # mask width, replace 1.5 with parameter value in the future
    ringmask = (r >= radpix - drhopix) * (r <= radpix + drhopix)

    # ### Now build the final matrix of masks
    ncoef = 2 * nsect + 2 * (m + 1)
    maskmat = np.zeros((ncoef, nx * nx))

    for j in range(0, nsect):  # radial masks
        maskmat[j, :] = np.ndarray.flatten(rwt[j] * ringmask)  # image pixels arranged in 1D array
        maskmat[j + nsect, :] = np.ndarray.flatten(fwt[j] * ringmask)

    for j in range(0, m + 1):  # cosine ans sine masks
        tmp = np.cos(phi * j) * ringmask
        if j > 0:
            cwt = tmp - np.sum(tmp) / nx / nx  # remove residual piston
        else:
            cwt = tmp
        tmp = np.sin(phi * j) * ringmask
        swt = tmp - np.sum(tmp) / nx / nx  # remove piston
        maskmat[2 * nsect + j, :] = np.ndarray.flatten(cwt)
        maskmat[2 * nsect + m + 1 + j, :] = np.ndarray.flatten(swt)

    # ### Main loop over the cube
    rad = np.zeros(nz)
    x0 = xc  # current ring center
    y0 = yc

    for i in range(0, nz):  # process full cube
        tmp = data_cube[i] - backgr
        arg = 2 * np.pi * (x0 * xx + y0 * yy) / nx  # FFT centering
        tmp = np.fft.ifft2(np.fft.fft2(tmp) * np.fft.fftshift(np.cos(arg) + np.sin(arg) * 1j)).real
        c = np.dot(maskmat, np.ndarray.flatten(tmp))
        c[0:nsect] = c[0:nsect] / c[nsect:2 * nsect]
        radii = c[0:nsect]
        dr = np.sum(radii) / nsect
        dx = np.sum(radii * xsect) / nsect * 2.3
        dy = np.sum(radii * ysect) / nsect * 2.3
        x0 += dx
        y0 += dy
        rad[i] = dr
        # end of main loop
        
    meanrad = np.mean(rad)

    return meanrad, rwidth

def ringproc(indir):
# Read the data and header
    fits_files = glob.glob(os.path.join(indir, '*.fits')) #Finds fits files in specified folder

    def extract_file_number(filename):
        fits_basename = os.path.basename(filename) #Extracts just file name from path
        
        match = re.search(r'(\d+)(?=\.fits$)', fits_basename)  #Extracts the number at the end of the file name
        
        return int(match.group(1)) if match else -1 #Returns number if found, otherwise sends it to the start of the list
    
    fits_files.sort(key=extract_file_number) #Orders the fits files
    
    fits_files = fits_files[-50:] #Take only last 50 frames
    
    frames_data = []
    
    for fits_file in fits_files:
        try:
            hdul = fits.open(fits_file)  # hdul.info() to see what it contains
        except FileNotFoundError as err:
            print(err)
            sys.exit()
        frames_data.append(hdul[0].data)
        hdul.close()
    
    data = np.array(frames_data)
    
    if data.shape[1] != data.shape[2]:
        min_side = max(data.shape[1], data.shape[2]) #Find minimum size of frames
        
        def extend_frame(frame): #Extend frames with black pixels to create square with min_side length
            cropped_frame = np.zeros((frame.shape[0], min_side, min_side), dtype = frame.dtype) #Create larger frame with all black pixels
            
            cropped_frame[:, :frame.shape[1], :frame.shape[2]] = frame #Copy original frame in (from top-left)
            
            return cropped_frame
        
        data_cube = extend_frame(data) #Extend all frames and store as data_cube, format: (f, x, y)
    else:
        data_cube = data
    
    return compute_ring_dimensions(data_cube)

folder = os.path.join('..', 'data') #Main folder path

key_pressed = False

def on_space(): #Set key press action
    global key_pressed
    key_pressed = True
    
keyboard.add_hotkey('space', on_space) #Listen for key press
    
def continious_loop(): #Continously run script ("space" to stop)
    next_call = time.time() #Sets next call time
    count = 0
    
    while True:
        if key_pressed == True: #End loop once "space" is pressed
            print('\033[91mPrinting loop ended\033[0m')
            break
        
        subsubsubfolders = []
        
        for root, dirs, files in os.walk(folder): #Get all folders three subfolders deep
            depth = root[len(folder):].count(os.sep)
            if depth == 2:
                subsubsubfolders.extend([os.path.join(root, d) for d in dirs])
                
        updated_subsubsubfolder = max(subsubsubfolders, key=os.path.getmtime) #Get latest updated folder
        
        ring_radius, ring_width = ringproc(updated_subsubsubfolder) #Runs function
        ring_ratio = ring_radius / ring_width #Computes ring radius to width ratio
        
        if count % 2 == 0:
            colour_code = '\033[94m' #Blue
            
        else:
            colour_code = '\033[92m' #Green
            
        print(f'{colour_code}r = {ring_radius}, dr = {ring_width}, r/dr = {ring_ratio} (want r/dr = 5)\033[0m')
        
        next_call += call_interval #Sets next call time
        time_to_sleep = max(0, next_call - time.time()) #Sets wait time (not including run time)
        time.sleep(time_to_sleep)
        
        count += 1

if __name__ == "__main__": #Check if python script is run directly
    print('\033[91mStarting ring radius and width printing loop, to exit press "space"\033[0m') #Progress (blue) print

    continious_loop()