#Import libraries
from alpaca.focuser import Focuser

F = Focuser('localhost:11111', 0) #Set qfocuser device path
F.Connect() #Connect to qfocuser

zero_position = int(F.MaxStep / 2) #Find zero postion (half of max steps to allow equal movement both ways)
#F.Move(zero_position)

#print(F.Position) #Gives position of qfocuser
#print(F.StepSize) #Gives the step size (in micrometres) for the qfocuser
#print(F.IsMoving) #Check if qfocuser is currently moving

#F.Move(F.Position + 500) #Move qfocuser
#F.Halt #Stops qfocuser if moving

F.Disconnect() #Disconnect from qfocuser