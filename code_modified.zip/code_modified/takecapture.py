#Notes:
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python takecapture.py {object_name} {data_folder}'

#Import libraries
import zwoasi as asi
import numpy as np
from astropy.io import fits
from datetime import datetime, timezone
import sys
import os

sdk_path = 'C:/Users/adamd/Desktop/PHYSICS 789/ASI SDK/lib/x64/ASICamera2.dll' #Set ASI SDK path

def take_data_capture(camera, capture_length, object_name, data_folder): #CURRENTLY DOES 1 FRAME, WANT TO UPDATE TO TAKE 2000 FRAMES
    #Get properties
    camera_properties = camera.get_camera_property() #Get camera properties
    
    timestamp = datetime.now(timezone.utc) #Get current time in UTC+0
    iso_timestamp = timestamp.isoformat() #Put timestamp in ISO format
    
    cdd_temp = C.get_control_value(asi.ASI_TEMPERATURE)[0] / 10 #Get ccd temperature (in Celsius)
    
    #Set output folder
    print('\033[94mCreating output folder\033[0m') #Progress (blue) print
    date_folder = timestamp.strftime('%Y-%m-%d')
    time_folder = timestamp.strftime('%H-%M-%S')
    
    output_folder = os.path.join(data_folder, date_folder, object_name, time_folder)
    os.makedirs(output_folder, exist_ok=True)
    
    #Take capture
    print('\033[94mStarting Capture\033[0m') #Progress (blue) print
    for i in range(capture_length):        
        camera.start_exposure() #Start single frame capture
        while camera.get_exposure_status() != asi.ASI_EXP_SUCCESS: #Wait for capture
            pass
        
        frame_buffer = C.get_data_after_exposure() #Collect capture buffer (1D array)
        frame = np.frombuffer(frame_buffer, dtype=np.uint8).reshape((64, 64)) #Format capture into 2D numpy array
    
        hdu = fits.PrimaryHDU(frame) #Set FITS image | NEED TO ADD HEADER TOO | MAY ALSO NEED TO MAKE CAMERA SETTINGS TXT OUPUT LIKE SHARPCAP DOES, IF CODE REQUIRES IT (CHECK)
        header = hdu.header
        
        #Header setup
        header['GAIN'] = 200 #Add GAIN in header
        header['EXPTIME'] = (1 * 10**-3, 'seconds') #Add EXPOSURE in header (in seconds)
        header['BITPIX'] = (8, 'bit-depth') #Add BITPIX in header
        header['DATE-OBS'] = (iso_timestamp, 'frame start') #Add DATE-OBS in header
        header['CCD-TEMP'] = (cdd_temp, 'celsius') #Add CCD-TEMP in header
        header['XPIXSZ'] = (camera_properties['PixelSize'], 'micrometres') #Add XPIXSZ in header (in micrometres)
        header['YPIXSZ'] = (camera_properties['PixelSize'], 'micrometeres') #Add YPIXSZ in header (in micrometres)
        
        fits_file = os.path.join(output_folder, f'capture_{i+1:04d}.fits') #Add frame name
        hdu.writeto(fits_file, overwrite=True) #Save frame

if __name__ == "__main__": #Check if python script is run directly
    if len(sys.argv) < 3:
        print('\033[91mError: Command should have format "python takecapture.py {object_name} {data_folder}"\033[0m') #Error (red) print
        sys.exit()
    
    object_name = sys.argv[1] #Get object name
    data_folder = os.path.relpath(os.path.abspath(sys.argv[2]), os.path.abspath(os.path.dirname(__file__))) #Find relative path

    print('\033[94mSetting Up Camera\033[0m') #Progress (blue) print
    
    #Find camera
    asi.init(sdk_path) #Initialse ASI SDK
    
    cameras = asi.list_cameras() #Get list of all connected ASI cameras
    if not cameras:
        print('\033[91mError: Camera Not Connected\033[0m') #Error (red) print
        sys.exit()
        
    C = asi.Camera(0) #Set ASI camera
    
    #Camera settings setup
    C.set_control_value(asi.ASI_GAIN, 200) #Adjust gain
    C.set_control_value(asi.ASI_EXPOSURE, 1 * 10**3)  #Adjust exposure (in microseconds)
    C.set_image_type(asi.ASI_IMG_RAW8) #Set 8-bit image format
    C.set_roi_format(64, 64, 1, asi.ASI_IMG_RAW8) #Set region of intrest (must be multiples of 8, taken from centre)
    
    take_data_capture(C, 2000, object_name, data_folder) #Take and save capture as data
    
    C.close() #Close camera
    print('\033[92mCapture saved\033[0m') #Success (green) print