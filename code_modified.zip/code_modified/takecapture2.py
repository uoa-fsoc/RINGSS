#Notes:
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python takecapture2.py {object_name}'

#Import libraries
import zwoasi as asi
import numpy as np
from astropy.io import fits
from datetime import datetime, timezone
import sys
import os

#Constants
sequence_length = 10 #Number of captures to take in sequence
frames = 2000 #Number of frames take per capture
exposure_length = 1 #ms | Expsoure length for single frame
gain = 200 #Camera gain
roi = 64 #Region-of-intrest for capture (must be multiple of 8, centred in camera)

#Paths
data_path = 'C:/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/data' #Absolute main data folder path
sdk_path = 'C:/Users/adamd/Desktop/PHYSICS 789/ASI SDK/lib/x64/ASICamera2.dll' #Absolute ASI SDK path

if __name__ == "__main__": #Check if python script is run directly
    if len(sys.argv) < 2:
        print('\033[91mError: Command should have format "python takecapture2.py {object_name}"\033[0m') #Error (red) print
        sys.exit()
    
    object_name = sys.argv[1] #Get object name
    data_folder = os.path.relpath(os.path.abspath(data_path), os.path.abspath(os.path.dirname(__file__))) #Set relative path to data folder

    print('\033[94mSetting up camera\033[0m') #Progress (blue) print
    
    #Find camera
    asi.init(sdk_path) #Initialse ASI SDK
    
    cameras = asi.list_cameras() #Get list of all connected ASI cameras
    if not cameras:
        print('\033[91mError: Camera not connected\033[0m') #Error (red) print
        sys.exit()
        
    C = asi.Camera(0) #Set ASI camera
    
    #Camera settings setup
    C.set_control_value(asi.ASI_GAIN, gain) #Adjust gain
    C.set_control_value(asi.ASI_EXPOSURE, exposure_length * 10**3)  #Adjust exposure (in microseconds)
    C.set_image_type(asi.ASI_IMG_RAW8) #Set 8-bit image format
    C.set_roi_format(roi, roi, 1, asi.ASI_IMG_RAW8) #Set region-of-intrest (must be multiple of 8, centred in camera)
    
    for i in range(sequence_length):
        print(f'\033[94mStarting capture {i + 1} of {sequence_length}\033[0m') #Progress (blue) print
        
        #Get camera properites
        print('\033[96mRetrieving camera properties\033[0m') #Smaller progress (light-blue) print
        camera_properties = C.get_camera_property() #Get camera properties
        
        timestamp = datetime.now(timezone.utc) #Get current time in UTC+0
        iso_timestamp = timestamp.isoformat() #Put timestamp in ISO format
        
        ccd_temp = C.get_control_value(asi.ASI_TEMPERATURE)[0] / 10 #Get ccd temperature (in Celsius)
        
        #Take capture
        print('\033[96mTaking capture\033[0m') #Smaller progress (light-blue) print
        
        capture = [] #Array to store captured frames
        
        C.start_video_capture() #Start video capture (fastest way to take multiple frames)
    
        for i in range(frames):
            #Get single frame
            frame_buffer = C.capture_video_frame() #Collect capture buffer (1D array)
            frame = np.frombuffer(frame_buffer, dtype=np.uint8).reshape((roi, roi)) #Format capture into 2D numpy array
        
            capture.append(frame) #Add frame to capture array   
        
        C.stop_video_capture() #End video capture
        
        #Set output folder
        print('\033[96mCreating output folder\033[0m') #Smaller progress (light-blue) print
        date_folder = timestamp.strftime('%Y-%m-%d') #Extract date from timestamp
        time_folder = timestamp.strftime('%H-%M-%S') #Extract time from timestamp
        
        output_folder = os.path.join(data_folder, date_folder, object_name, time_folder) #Set full output folder path
        os.makedirs(output_folder, exist_ok=True) #Create all output folders (if needed)
        
        #Create headers and save capture
        print('\033[96mSaving capture\033[0m') #Smaller progress (light-blue) print
        
        for i, frame in enumerate(capture):
            hdu = fits.PrimaryHDU(frame) #Set FITS image
            header = hdu.header
            
            #Header setup
            header['OBJECT'] = (object_name)
            header['GAIN'] = gain #Add GAIN in header
            header['EXPTIME'] = (exposure_length * 10**-3, 'seconds') #Add EXPOSURE in header (in seconds)
            header['BITPIX'] = (8, 'bit-depth') #Add BITPIX in header
            header['DATE-OBS'] = (iso_timestamp, 'capture start') #Add DATE-OBS in header
            header['CCD-TEMP'] = (ccd_temp, 'celsius') #Add CCD-TEMP in header
            header['XPIXSZ'] = (camera_properties['PixelSize'], 'micrometres') #Add XPIXSZ in header (in micrometres)
            header['YPIXSZ'] = (camera_properties['PixelSize'], 'micrometeres') #Add YPIXSZ in header (in micrometres)
            
            fits_file = os.path.join(output_folder, f'{object_name}_{i+1:04d}.fits') #Add frame name
            hdu.writeto(fits_file, overwrite=True) #Save frame
    
    C.close() #Close camera
    print('\033[92mCapture sequence completed\033[0m') #Success (green) print
    
    os.startfile(os.path.join(data_folder, (datetime.now(timezone.utc)).strftime('%Y-%m-%d'), object_name)) #Open capture sequence folder