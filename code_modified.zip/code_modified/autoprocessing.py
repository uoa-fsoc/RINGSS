#Notes:
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python autoprocessing.py {hr_number} "{capture_folder}"'
    #Has input for HR number, NEED TO MAKE A FUNCTION THAT CONVERTS STAR NAME TO HR NUMBER THEN REMOVE HR INPUT AND PASSING FROM THIS FILE ENTIRELY
    


#Import libraries
import sys
import os
import subprocess

#Set path to python.exe
python = 'C:/Users/adamd/miniconda3/python.exe'

#Set path to parameters file
parameters_path = 'par-ardmore.json'

def produce_statistical_moments(hr, capturesdir, outputdir):
    print("Calculating statistical moments (cube2.py)")
    
    #Run cube2.py for all individual capture folders
    for root, dirs, files in os.walk(capturesdir):
        for dir_name in dirs:
            capture_path = os.path.join(capturesdir, dir_name) #Join input and capture paths
            
            subprocess.run([python, 'cube2.py', hr, capture_path, outputdir], text=True) #Run cube2.py

if __name__ == "__main__": #Check if python script is run directly
    print("--------------------------------------------")
    print("Starting auto-processing (autoprocessing.py)")
    
    if len(sys.argv) < 1: #Make sure correct inputs are given
        print('Usage: python autoprocessing.py {hr_number} "{captures_folder}"')
        sys.exit()
  
    #Assign input fields
    hr = sys.argv[1]
    capturesdir = '../data/' + sys.argv[2]
    
    basename = os.path.basename(os.path.normpath(capturesdir)) #Extracts time from the folder name
    output_path = os.path.join(os.getcwd(), '../outputs/' + basename) #Creates output path
    stm_path = output_path + '/' + basename #Record stm file path
    os.makedirs(output_path, exist_ok=True) #Creates output folder
    
    produce_statistical_moments(hr, capturesdir, output_path) #Computes all statistical moments (cube2.py)
    subprocess.run([python, 'createstm.py', output_path], text=True) #Creates stm file (createstm.py)
    subprocess.run([python, 'readstm.py', parameters_path, stm_path], text=True) #Creates prof file (readstm.py)
    
    print("--------------------------------------------")