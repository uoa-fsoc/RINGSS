#Notes:
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python maintaining.py'
    #This script assumes the star is already centred in a 64x64 roi and in-focus

#Import libraries
import zwoasi as asi
from alpaca.focuser import Focuser
#from astropy.stats import sigma_clipped_stats
import numpy as np
import sys
import keyboard

#Set constants
optimal_radius = 10 #pixels | Ring radius that we are aimming for
action_radius_range = 0.5 #pixels | Amount off ring radius that is allowed before moving focuser (optimal radius +- action_radius_range)
move_radius_range = 0.1 #pixels | Amount off ring radius that is aimmed for when adjusting focuser (optimal radius +- move_radius_range)

# focusing_step = 100 #micormetres | Focuser step size for focusing star | useful for next version of script
initial_defocus_step = 300 #micormetres | Focuser step size for initial decfocusing of star
step_constant = 10 #micrometeres/pixel | Constant that converts difference in pixels to corresponding focusing step

avg_frames = 50 #frames | Amount of frames captured for determining ring radius

exposure_length = 1 #ms | Expsoure length for single frame
gain = 200 #Camera gain
roi = 64 #Region-of-intrest for capture (must be multiple of 8, centred in camera)

#background_sigma = 3 #Number of std's for pixel to be removed from background statistics calculations

# def focus_capture(C): #useful for next version of script
#     camera_properties = C.get_camera_property() #Get camera properties
#     C.set_roi_format(camera_properties['MaxWidth'], camera_properties['MaxHeight'], 1, asi.ASI_IMG_RAW8) #Set camera ROI to max

#     C.start_exposure() #Start single frame capture
#     while C.get_exposure_status() != asi.ASI_EXP_SUCCESS: #Wait for capture
#         pass
    
#     capture_buffer = C.get_data_after_exposure() #Collect capture buffer (1D array)
#     capture = np.frombuffer(capture_buffer, dtype=np.uint8).reshape((camera_properties['MaxWidth'], camera_properties['MaxHeight'])) #Format capture into 2D numpy array
    
#     return capture

# def get_FWHM(frame, centre_x, centre_y): #INTAKE CENTRE X AND Y VALUES, COMPUTE THESE FIRST TIME FWHM IS RUN AND KEEP | useful for next version of script
#     mean, median, std = sigma_clipped_stats(frame, sigma = background_sigma) #Get background statistics | sigma value removes pixels that many std's or more from the mean
    
#     #I THINK WE CAN JUST KEEP CENTRE AND FRAMEISH SIZE FROM FIRST CAPTURE, THEN THE REST CAN SKIP OVER SECTIONS THAT CALC CENTRE, FRAME SIZE, ALONG WITH NOT NEEDING TO USE EST FWHM

#     return 1 #ACTUALLY FIND AND RETURN FWHM

def get_ring_dimensions(camera, frames):

    capture = [] #Array to store captured frames
    
    C.start_video_capture() #Start video capture (fastest way to take multiple frames)

    for i in range(frames):
        #Get single frame
        frame_buffer = C.capture_video_frame() #Collect capture buffer (1D array)
        frame = np.frombuffer(frame_buffer, dtype=np.uint8).reshape((roi, roi)) #Format capture into 2D numpy array
    
        capture.append(frame) #Add frame to capture array   
    
    C.stop_video_capture() #End video capture
        
    #Calculate ring radius and width
    nz, ny, nx = capture.shape  # e.g., 2000 frames of 64x64 pixels
    
    # Average the first nstart frames to get a representative ring image
    nstart = 50
    imav = np.average(capture[0:nstart], axis=0)  # (64, 64) average image
    
    # Create coordinate grids centered around the image center
    i = np.indices((nx, nx))
    yy = i[0] - nx / 2  # vertical distance from center
    xx = i[1] - nx / 2  # horizontal distance from center
    
    # Convert Cartesian coordinates to polar
    r = np.sqrt(np.square(xx) + np.square(yy))  # radial distance from center
    phi = np.arctan2(yy, xx)  # angle (radians) from center
    
    # Prepare radial and angular masks
    m = 20       # max angular frequency for Fourier components
    nsect = 8    # number of angular sectors to divide the ring
    rwt = np.zeros((nsect, nx, nx))  # weights for computing sector-wise radius
    fwt = np.zeros((nsect, nx, nx))  # binary masks for flux in each sector
    sect = 2. * np.pi / nsect        # angular width of each sector (radians)
    
    # Define sector masks in polar space
    for j in range(nsect):
        sector = (phi >= (sect * (j - nsect / 2))) & (phi < (sect * (j + 1 - nsect / 2)))
        fwt[j] = sector.astype(float)
        rwt[j] = sector * r  # multiply by radius to use in weighted sum
    
    # Diagnostic image to test radial mask layout (optional visualization aid)
    test = np.zeros((nx, nx))
    for j in range(nsect):
        test += rwt[j] * (j + 1)
    
    # Compute angle (in radians) for each sector center
    phisect = sect * (np.arange(nsect, dtype=float) - nsect / 2 + 0.5)
    xsect, ysect = np.cos(phisect), np.sin(phisect)  # unit vectors for each sector
    
    # Estimate background level from left/right edges of image
    backgr = np.median([imav[:, 0], imav[:, nx - 1]])
    tmp = imav - backgr  # subtract background from averaged image
    
    # Estimate total intensity and flux centroid (center of light)
    itot = np.sum(tmp)
    xc = np.sum(tmp * xx) / itot
    yc = np.sum(tmp * yy) / itot
    
    # Rough shift to center the ring by integer pixel values
    imavcent = np.roll(tmp, (int(-xc), int(-yc)), axis=(1, 0))
    
    # Compute preliminary radii in each angular sector
    radii = np.zeros(nsect)
    for j in range(nsect):
        radii[j] = np.sum(imavcent * rwt[j]) / np.sum(imavcent * fwt[j])
    
    # Compute small offset to more accurately center the ring
    dx1 = np.sum(radii * xsect) / nsect * 2.3
    dy1 = np.sum(radii * ysect) / nsect * 2.3
    xc += dx1
    yc += dy1  # refined center
    
    # Apply sub-pixel shift via Fourier shift theorem
    arg = 2 * np.pi * (dx1 * xx + dy1 * yy) / nx
    imavcent = np.fft.ifft2(np.fft.fft2(imavcent) *
                            np.fft.fftshift(np.cos(arg) + np.sin(arg) * 1j)).real
    
    # Recalculate sector radii with improved centering
    for j in range(nsect):
        radii[j] = np.sum(imavcent * rwt[j]) / np.sum(imavcent * fwt[j])
    radpix = np.sum(radii) / nsect  # average ring radius (pixels)
    
    # Estimate ring width by thresholding at 10% of max and measuring radial variance
    tmp = imavcent - 0.1 * np.max(imavcent)
    tmp *= (tmp > 0)  # keep only values above threshold
    radvar = np.sum(tmp * (r - radpix) ** 2) / np.sum(tmp)
    rwidth = pow(radvar, 0.5) * 2.35  # FWHM assuming Gaussian shape
    
    # Refine background using pixels well outside the ring
    backgr += np.median(imavcent * (r > 1.5 * radpix))
    
    # Create a binary ring mask (annulus) for analysis
    drhopix = 1.5 * rwidth  # mask half-width
    ringmask = (r >= radpix - drhopix) & (r <= radpix + drhopix)
    
    # Construct the basis matrix for projection (masks × pixels)
    ncoef = 2 * nsect + 2 * (m + 1)
    maskmat = np.zeros((ncoef, nx * nx))
    
    # Add radial and angular sector masks to the matrix
    for j in range(nsect):
        maskmat[j, :] = np.ndarray.flatten(rwt[j] * ringmask)  # radius weighting
        maskmat[j + nsect, :] = np.ndarray.flatten(fwt[j] * ringmask)  # flux
    
    # Add angular Fourier basis functions (cos and sin components)
    for j in range(m + 1):
        tmp = np.cos(phi * j) * ringmask
        if j > 0:
            cwt = tmp - np.sum(tmp) / nx / nx  # remove average value
        else:
            cwt = tmp
        tmp = np.sin(phi * j) * ringmask
        swt = tmp - np.sum(tmp) / nx / nx
        maskmat[2 * nsect + j, :] = np.ndarray.flatten(cwt)
        maskmat[2 * nsect + m + 1 + j, :] = np.ndarray.flatten(swt)
    
    # === Main loop to process each frame in the cube ===
    rad = np.zeros(nz)  # will store estimated ring radius per frame
    x0, y0 = xc, yc     # initial center coordinates
    
    for i in range(nz):
        tmp = capture[i] - backgr  # subtract background
        arg = 2 * np.pi * (x0 * xx + y0 * yy) / nx  # phase shift
        tmp = np.fft.ifft2(np.fft.fft2(tmp) * np.fft.fftshift(np.cos(arg) + np.sin(arg) * 1j)).real
    
        # Project frame onto basis masks to extract coefficients
        c = np.dot(maskmat, np.ndarray.flatten(tmp))
    
        # Normalize radii by total flux in each sector
        c[0:nsect] = c[0:nsect] / c[nsect:2 * nsect]
        radii = c[0:nsect]
        dr = np.sum(radii) / nsect
    
        # Estimate sub-pixel shift based on sector radii
        dx = np.sum(radii * xsect) / nsect * 2.3
        dy = np.sum(radii * ysect) / nsect * 2.3
        x0 += dx
        y0 += dy
    
        rad[i] = dr  # save current frame's average ring radius
    
    # After loop, calculate overall mean radius across frames
    meanrad = np.mean(rad)
    
    return meanrad, rwidth  # return average radius and ring width
    
#Script start via command line
if __name__ == "__main__": #Check if python script is run directly
    print('\033[91mStarting ring maintaing\033[0m') #Progress (blue) print
    print('\033[91mSetting up camera and focuser\033[0m') #Progress (blue) print

    #Setup camera
    sdk_path = 'C:/Users/adamd/Desktop/PHYSICS 789/ASI SDK/lib/x64/ASICamera2.dll' #Set ASI SDK path
    asi.init(sdk_path) #Initialse ASI SDK
    
    cameras = asi.list_cameras() #Get list of all connected ASI cameras
    if not cameras:
        print('\033[91mError: Camera Not Connected\033[0m') #Error (red) print
        sys.exit()
        
    C = asi.Camera(0) #Set ASI camera
    
    C.set_control_value(asi.ASI_GAIN, gain) #Adjust gain
    C.set_control_value(asi.ASI_EXPOSURE, exposure_length * 10**3)  #Adjust exposure (in microseconds)
    C.set_image_type(asi.ASI_IMG_RAW8) #Set 8-bit image format
    C.set_roi_format(roi, roi, 1, asi.ASI_IMG_RAW8) #Set region-of-intrest (must be multiple of 8, centred in camera)
    
    #Setup focuser
    F = Focuser('localhost:11111', 0) #Set focuser device path
    F.Connect() #Connect to focuser
    
    # #Find focal point | useful for next version of script
    # print('\033[91mFinding focal point\033[0m') #Progress (blue) print
    # initial_focal_capture = focus_capture(C) #Get initial focus capture
    # initial_FWHM = get_FWHM(initial_focal_capture, None, None) #Get initial focus FWHM
    
    # F.Move(F.Position + focusing_step) #Move focuser clockwise by focusing step
    # while F.IsMoving == True: #Wait for focuser to stop moving
    #     pass
    
    # direction_focal_capture = focus_capture(C) #Get direction focus capture
    # direction_FWHM = get_FWHM(direction_focal_capture) #Get direction focus FWHM
    
    # if direction_FWHM < initial_FWHM: #Checks to see if moving in focusing direction (lower FWHM -> more in-focus)
    #     focus_direction = 1 #Sets focus direction to clockwise
    #     FWHM_B = direction_FWHM #Sets second capture as more in-focus
    #     FWHM_A = initial_FWHM #Sets first capture as less in-focus
    # else:
    #     focus_direction = 0 #Sets focus direction to anti-clockwise
    #     FWHM_B = initial_FWHM #Sets first capture as more in-focus
    #     FWHM_A = direction_FWHM #Sets second capture as less in-focus
        
    # while FWHM_B < FWHM_A:
    #     F.Move(F.Position + focusing_step) #Move focuser clockwise by focusing step
    #     while F.IsMoving == True: #Wait for focuser to stop moving
    #         pass
        
    #     FWHM_A = FWHM_B #Move to next FWHM
        
    #     new_focal_capture = focus_capture(C) #Get new focus capture
    #     B_FWHM = get_FWHM(new_focal_capture) #Get new focus FWHM
        
    #Set to optimal ring radius
    print('\033[94mMoving to initial defocus\033[0m') #Progress (blue) print
    F.Move(F.Position + initial_defocus_step) #Move focuser clockwise by initial defocus step
    while F.IsMoving == True: #Wait for focuser to stop moving
        pass
    
    current_radius, current_width = get_ring_dimensions(C, avg_frames) #Get current ring radius and width
    
    print('\033[94mSetting ring radius to optimal\033[0m') #Progress (blue) print
    while current_radius < optimal_radius - move_radius_range or optimal_radius + move_radius_range < current_radius:
        step = int(np.ceil((optimal_radius - current_radius) * step_constant)) #Calculate step size based off distance from optimal radius
        
        F.Move(F.Position + initial_defocus_step) #Move focuser clockwise by correction step
        while F.IsMoving == True: #Wait for focuser to stop moving
            pass
        
        current_radius, current_width = get_ring_dimensions(C, avg_frames) #Get current ring radius and width
    
    print(f'\033[94mr = {current_radius}, dr = {current_width} \033[0m') #Progress (blue) print
    
    #Setup continous loop stop key
    key_pressed = False

    def on_space(): #Set key press action
        global key_pressed
        key_pressed = True
        
    keyboard.add_hotkey('space', on_space) #Listen for key press
    
    #Constantly maintaing ring radius
    print('\033[94mInitiating ring radius maintaining, press "space" to end\033[0m') #Progress (blue) print
    while True:
        if key_pressed == True: #End loop once "space" is pressed
            print('\033[38;5;208mRing radius maintaing ended by user\033[0m') #Warning (orange) print
            break    
        
        if current_radius < optimal_radius - action_radius_range or optimal_radius + action_radius_range < current_radius:
           print('\033[96mRing radius out of optimal, adjusting\033[0m') #Smaller progress (light-blue) print
           while current_radius < optimal_radius - move_radius_range or optimal_radius + move_radius_range < current_radius:
               step = int(np.ceil((optimal_radius - current_radius) * step_constant)) #Calculate step size based off distance from optimal radius
               
               F.Move(F.Position + initial_defocus_step) #Move focuser clockwise by correction step
               while F.IsMoving == True: #Wait for focuser to stop moving
                   pass
               
               current_radius, current_width = get_ring_dimensions(C, avg_frames) #Get current ring radius and width
               
           print(f'\033[96mr = {current_radius}, dr = {current_width}\033[0m') #Smaller progress (light-blue) print
    
    #Disconnect from camera and focuser | only run if user ends continous loop with "space"
    C.close() #Close camera
    F.Disconnect() #Disconnect from focuser