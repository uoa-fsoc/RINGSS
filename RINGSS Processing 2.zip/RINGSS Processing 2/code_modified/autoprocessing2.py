#Notes:
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python autoprocessing2.py {hr_number} {capture_folder} optional:{specific_capture_numbers}'
    #Has input for HR number, NEED TO MAKE A FUNCTION THAT CONVERTS STAR NAME TO HR NUMBER THEN REMOVE HR INPUT AND PASSING FROM THIS FILE ENTIRELY
    
    

#Import libraries
import sys
import os
import subprocess
import re
import glob

#Set path to python.exe
python = 'C:/Users/adamd/miniconda3/python.exe'

#Set path to parameters file
parameters_path = 'par-ardmore.json'

def create_singles(inputdir, outputdir, object_name):
    print('\033[94mCreating singles folder\033[0m') #Progress (blue) print
    
    #Create all singles folders and subfolders
    os.makedirs(outputdir, exist_ok=True) #Create singles folder
    os.makedirs(outputdir + '/' + object_name + ' ((moments))', exist_ok=True) #Create singles moments subfolder
    os.makedirs(outputdir + '/' + object_name + ' ((previews))', exist_ok=True) #Create singles previews subfolder
    os.makedirs(outputdir + '/' + object_name + ' ((stms))', exist_ok=True) #Create singles stms subfolder
    os.makedirs(outputdir + '/' + object_name + ' ((profiles))', exist_ok=True) #Create singles profiles subfolder
    
    def order_key(inputdir):
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', inputdir)] #Splits string into parts of digits and non-digits
    
    dirs = [f for f in os.listdir(inputdir) if os.path.isdir(os.path.join(inputdir, f))] #Find all capture folders
        
    dirs.sort(key=order_key) #Order capture folders the same way windows file explorer does
    
    #Run cube2.py for all captures
    print('\033[94mCalculating statistical moments \033[95m(cube2.py)\033[0m') #Progress (blue) print and script (purple) print
    
    for i, dir_name in enumerate(dirs):
        single_path = os.path.join(inputdir, dir_name) #Join input, capture
        
        subprocess.run([python, 'cube2.py', hr, single_path, outputdir + '/' + object_name, str(i + 1)], text=True) #Run cube2.py, in singles mode
    
    #Run createstm.py for all captures
    print('\033[94mGathering data and parameters for single captures \033[95m(createstm.py)\033[0m') #Progress (blue) print and script (purple) print
    
    glob_path = glob.escape(os.path.abspath(outputdir + '/' + object_name + ' ((moments))')) #Path that uses escape (glob uses sqaure brackets itself)
    json_files = glob.glob(os.path.join(glob_path, '*.json')) #Get all json files in folder
    
    for i, json_file in enumerate(json_files):
        subprocess.run([python, 'createstm.py', json_file, str(i + 1)], text=True) #Creates stm file (createstm.py)
    
    #Run readstm.py for all captures
    print('\033[94mRestoring turbulence profile for single captures \033[95m(readstm.py)\033[0m') #Progress (blue) print and script (purple) print
    
    glob_path = glob.escape(os.path.abspath(outputdir + '/' + object_name + ' ((stms))')) #Path that uses escape (glob uses sqaure brackets itself)
    stm_files = glob.glob(os.path.join(glob_path, '*.stm')) #Get all stm files in folder
    
    for i, stm_file in enumerate(stm_files):
        subprocess.run([python, 'readstm.py', parameters_path, stm_file, str(i + 1)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL) #Creates prof file (readstm.py), with errors muted

if __name__ == "__main__": #Check if python script is run directly
    print('\033[94mStarting auto-processing\033[0m') #Progress (blue) print
    
    if len(sys.argv) < 3: #Make sure correct inputs are given
        print('\033[91mError: command should have format "python autoprocessing2.py {hr_number} {captures_folder} optional:{specific_capture_numbers}(e.g: 1,2,4)"\033[0m') #Error (red) print
        sys.exit()
  
    #Assign input fields
    hr = sys.argv[1]
    capturesdir = os.path.relpath(os.path.abspath(sys.argv[2]), os.path.abspath(os.path.dirname(__file__))) #Find relative path
    
    if len(sys.argv) > 3:
        specific_capture_numbers = [int(num) for num in sys.argv[3].split(',')] #Split string of folder numbers into list
        specific_capture_numbers.sort() #Put list in numerical order
    else:
        specific_capture_numbers = 0
        
    #Extract normal path
    normalised_path = os.path.normpath(capturesdir) #Nomarlised path
    path_parts = normalised_path.split(os.sep) #Split path into folders
    
    #Extract date and object names
    date_name = path_parts[-2] #Extract date name from path
    object_name = path_parts[-1] #Extract capture name from path
    
    #Create main output path
    main_output_path = os.path.join(os.getcwd(), '../outputs/' + date_name + '/' + object_name) #Create date and object output path
    os.makedirs(main_output_path, exist_ok=True) #Create object output folder
    
    #Set singles path
    singles_path = main_output_path + '/' + object_name + ' ((singles))'
    
    #Create singles if needed
    if not os.path.exists(os.path.join(singles_path, object_name + ' ((profiles))')): #Check if singles moments subfolder exists
        create_singles(capturesdir, singles_path, object_name) #Create singles
    
    glob_path = glob.escape(os.path.join(singles_path, object_name + ' ((profiles))')) #Path that uses escape (glob uses sqaure brackets itself)
    prof_files = glob.glob(os.path.join(glob_path, '*.prof')) #Get all prof files in folder
    
    if not len(prof_files) > 0: #Check to see if any prof files exist
        create_singles(capturesdir, singles_path, object_name) #Create singles
        
    #Check if all specifc captures exist
    print('\033[94mLooking for requested captures\033[0m') #Progress (blue) print
    
    if specific_capture_numbers == 0:
        combination_string = 'all' #State all captures were used
    else:
        non_existing_captures = []
        
        #Check to see if all selected folders exist
        for capture_number in specific_capture_numbers:
            if capture_number > len(prof_files):
                non_existing_captures.append(capture_number)
                
        if len(non_existing_captures) > 0:
            if len(non_existing_captures) > 1:
                string_non_existing_captures = ', '.join(map(str, non_existing_captures[:-1])) + ' and ' + str(non_existing_captures[-1]) if len(non_existing_captures) > 1 else str(non_existing_captures[0]) #Join folder numbers in non_existing_captures list

                print(f'\033[91mError: captures {string_non_existing_captures} do not exist, only {len(prof_files)} captures exist\033[0m') #Error (red) print
                sys.exit()
            else:
                print(f'\033[91mError: capture {non_existing_captures[0]} does not exist, only {len(prof_files)} captures exist\033[0m') #Error (red) print
                sys.exit()
        
        combination_string = ','.join(map(str, specific_capture_numbers)) #Join capture numbers from selected capture list

    complete_combination_string = '((' + combination_string + '))'
    
    output_path = os.path.relpath(os.path.abspath(main_output_path), os.path.abspath(os.path.dirname(__file__))) #Find relative output path
    json_path = os.path.join(output_path, object_name + ' ((singles))', object_name + ' ((moments))') #Puts moments path together
    stm_path = os.path.join(output_path, object_name + ' ' + complete_combination_string) #Puts stm path together
    
    print('\033[94mGathering data and parameters for combined capture \033[95m(createstm.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'createstm.py', json_path, complete_combination_string], text=True) #Creates stm file (createstm.py)
    
    print('\033[94mRestoring turbulence profile for combined capture \033[95m(readstm.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'readstm.py', parameters_path, stm_path], text=True) #Creates prof file (readstm.py)
    print('\033[92mTurbulence profile successfully created\033[0m') #Success (green) print