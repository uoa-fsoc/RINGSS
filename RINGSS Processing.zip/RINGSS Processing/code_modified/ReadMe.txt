Pyhon code for RINGSS data processing
A. Tokovinin 2023-03-13

1. Documents
-----------------
ReadMe.txt - this file
ringss-python2.pdf - description of the code

2. Python modules
------------------
ASI290mm.py
aberration.py
aberstm.py
aweight.py
corcent.py
cube2.py
getimage.py
getweight5.py
getzen.py
profrest5.py
readstarcat.py
readstm.py
zernike.py

3. Configuration files
------------------------
par-laserena.json
starcat.json
weights.json
zmat.json
