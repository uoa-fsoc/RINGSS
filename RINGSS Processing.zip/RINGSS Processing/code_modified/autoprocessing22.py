#Notes:
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/code_modified"', then 'python autoprocessing2.py {hr_number} {capture_folder} optional:{specific_folder_numbers}'
    #Has input for HR number, NEED TO MAKE A FUNCTION THAT CONVERTS STAR NAME TO HR NUMBER THEN REMOVE HR INPUT AND PASSING FROM THIS FILE ENTIRELY
    
    

#Import libraries
import sys
import os
import subprocess
import re
import glob

#Set path to python.exe
python = 'C:/Users/adamd/miniconda3/python.exe'

#Set path to parameters file
parameters_path = 'par-ardmore.json'

def create_singles(inputdir, outputdir, object_name):
    print('\033[94mCreating Output Folders\033[0m') #Progress (blue) print
    
    #Create all singles folders and subfolders
    os.makedirs(outputdir, exist_ok=True) #Create singles folder
    os.makedirs(outputdir + '/' + object_name + ' [moments]', exist_ok=True) #Create singles moments subfolder
    os.makedirs(outputdir + '/' + object_name + ' [previews]', exist_ok=True) #Create singles previews subfolder
    os.makedirs(outputdir + '/' + object_name + ' [stms]', exist_ok=True) #Create singles stms subfolder
    os.makedirs(outputdir + '/' + object_name + ' [profiles]', exist_ok=True) #Create singles profiles subfolder
    
    def order_key(inputdir):
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', inputdir)] #Splits string into parts of digits and non-digits
    
    dirs = [f for f in os.listdir(inputdir) if os.path.isdir(os.path.join(inputdir, f))] #Find all capture folders
        
    dirs.sort(key=order_key) #Order capture folders the same way windows file explorer does
    
    #Run cube2.py for all captures
    print('\033[94mCalculating statistical moments \033[95m(cube2.py)\033[0m') #Progress (blue) print and script (purple) print
    
    for i, dir_name in enumerate(dirs):
        single_path = os.path.join(inputdir, dir_name) #Join input, capture
        
        subprocess.run([python, 'cube2.py', hr, single_path, outputdir + '/' + object_name, str(i + 1)], text=True) #Run cube2.py, in singles mode
   
    #create single stms and profs-------------------
    
    #Run createstm.py for all capture
    print('\033[94mGathering data and parameters \033[95m(createstm.py)\033[0m') #Progress (blue) print and script (purple) print
    
    #FOR LOOP TO FIND ALL JSONS, THEN EDIT BELOW FOR LOOP TO DO ONE JSON AT A TIME, THEN CHANGE createst.py TO ONLY PRINT 'M' LINE AND ALSO CHANGE WHERE OUTPUT IS AND HOW IT TAKES THE INPUT (INPUT IS JSON FILE ITSELF, NOT FOLDER TO SEARCH)
    
    for i, dir_name in enumerate(dirs):
        subprocess.run([python, 'createstm.py', outputdir + '/ [moments]' + object_name, str(i + 1)], text=True) #Creates stm file (createstm.py)
    
    sys.exit() #JUST FOR TESTING

def create_output_paths(capturesdir, specific_folder_numbers):
    def order_key(capture_folder):
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', capture_folder)] #Splits string into parts of digits and non-digits
    
    dirs = [f for f in os.listdir(capturesdir) if os.path.isdir(os.path.join(capturesdir, f))] #Find all capture folders
        
    dirs.sort(key=order_key) #Order capture folders the same way windows file explorer does
    
    if specific_folder_numbers == 0:
        combination_string = 'all' #State all captures were used
    else:
        non_existing_folders = []
        
        #Check to see if all selected folders exist
        for folder_number in specific_folder_numbers:
            if folder_number > len(dirs):
                non_existing_folders.append(folder_number)
                
        if len(non_existing_folders) > 0:
            if len(non_existing_folders) > 1:
                string_non_existing_folders = ', '.join(map(str, non_existing_folders[:-1])) + ' and ' + str(non_existing_folders[-1]) if len(non_existing_folders) > 1 else str(non_existing_folders[0]) #Join folder numbers in non_existing_folders list

                print(f'\033[91mError: folders {string_non_existing_folders} do not exist, only {len(dirs)} folders exist\033[0m') #Error (red) print
                sys.exit()
            else:
                print(f'\033[91mError: folder {non_existing_folders[0]} does not exist, only {len(dirs)} folders exist\033[0m') #Error (red) print
                sys.exit()
                
        combination_string = ','.join(map(str, specific_folder_numbers)) #Join capture numbers from selected capture list
    
    # #Create/Override combination output subfolder
    # full_output_name = object_name + ' [' + combination_string + ']' #CHANGE TO MATCH SELECTED CAPTURES
    # full_output_path = os.path.join(capture_output_path, full_output_name) #Create output path

    # if os.path.exists(full_output_path): #Remove output subfolder and content if it exists
    #     shutil.rmtree(full_output_path)
    
    # os.makedirs(full_output_path) #Create output folder
    
    # rel_output_path = os.path.relpath(os.path.abspath(full_output_path), os.path.abspath(os.path.dirname(__file__))) #Find relative path
    # rel_stm_path = rel_output_path + '/' + full_output_name #Record stm file path
    stm_path = capture_output_path
    
    return dirs, capture_output_path, stm_path

def produce_statistical_moments(hr, capturesdir, outputdir, specific_folder_numbers, dirs):
    print('\033[94mCalculating statistical moments \033[95m(cube2.py)\033[0m') #Progress (blue) print and script (purple) print
    
    if specific_folder_numbers == 0:
        #Run cube2.py for all individual capture folders
        for dir_name in dirs:
                capture_path = os.path.join(capturesdir, dir_name) #Join input and capture paths
                
                subprocess.run([python, 'cube2.py', hr, capture_path, outputdir], text=True) #Run cube2.py
    else: 
        #Run cube2.py for selected individual capture folders
        for i, dir_name in enumerate(dirs):
            if (i + 1) in specific_folder_numbers: #Use i+1 since lists start from 0, but we are starting from 0
                capture_path = os.path.join(capturesdir, dir_name) #Join input and capture paths
                
                subprocess.run([python, 'cube2.py', hr, capture_path, outputdir], text=True) #Run cube2.py

if __name__ == "__main__": #Check if python script is run directly
    print('\033[94mStarting auto-processing \033[95m(autoprocessing2.py)\033[0m') #Progress (blue) print and script (purple) print
    
    if len(sys.argv) < 3: #Make sure correct inputs are given
        print('\033[91mError: command should have format "python autoprocessing2.py {hr_number} {captures_folder} optional:{specific_folder_numbers}(e.g: 1,2,4)"\033[0m') #Error (red) print
        sys.exit()
  
    #Assign input fields
    hr = sys.argv[1]
    capturesdir = os.path.relpath(os.path.abspath(sys.argv[2]), os.path.abspath(os.path.dirname(__file__))) #Find relative path
    
    if len(sys.argv) > 3:
        specific_folder_numbers = [int(num) for num in sys.argv[3].split(',')] #Split string of folder numbers into list
        specific_folder_numbers.sort() #Put list in numerical order
    else:
        specific_folder_numbers = 0
        
    #Extract normal path
    normalised_path = os.path.normpath(capturesdir) #Nomarlised path
    path_parts = normalised_path.split(os.sep) #Split path into folders
    
    #Extract date and object names
    date_name = path_parts[-2] #Extract date name from path
    object_name = path_parts[-1] #Extract capture name from path
    
    #Create main output path
    main_output_path = os.path.join(os.getcwd(), '../outputs/' + date_name + '/' + object_name) #Create date and object output path
    os.makedirs(main_output_path, exist_ok=True) #Create object output folder
    
    #Set singles path
    singles_path = main_output_path + '/' + object_name + ' [singles]'
    
    #Create singles if needed
    if not os.path.exists(singles_path + '/' + object_name + ' [moments]'): #Check if singles moments subfolder exists
        create_singles(capturesdir, singles_path, object_name) #Create singles
    
    json_files = glob.glob(os.path.join(singles_path + '/' + object_name + ' [moments]/', '*.json')) #Find json files, if any
    
    if not len(json_files) > 0: #Check to see if any json files exist
        create_singles(capturesdir, singles_path, object_name) #Create singles
    
    #produce_statistical_moments(hr, capturesdir, output_path, specific_folder_numbers, dirs) #Computes all statistical moments (cube2.py)
    #subprocess.run([python, 'createstm.py', output_path], text=True) #Creates stm file (createstm.py)
    #subprocess.run([python, 'readstm.py', parameters_path, stm_path], text=True) #Creates prof file (readstm.py)