#Import libraries
import sys
import numpy as np
import zwoasi as asi
import cv2
import matplotlib.pyplot as plt
import json

#Optional: Wanted conjugation distances
conjugation_distances = [500] #m

#Adjustable parameters
threshold = 0.1 #Brightness threshold to identify stars
roi = 200 #pixels | Capture region-of-interest
sep_type = 0 #Separation type used to use either closest two stars (0) or furthest two stars (1)

#Instrument constants
p = 2.9 * 10**-6 #m | Camera pixel size

#Set paths
parameters_path = 'par-ardmore.json' #Relative parameters file path
sdk_path = 'C:/Users/adamd/Desktop/PHYSICS 789/ASI SDK/lib/x64/ASICamera2.dll' #Absolute ASI SDK path

#Script start via command line
if __name__ == "__main__": #Check if python script is run directly
    if len(sys.argv) < 5:
        print('\033[91mError: Command should have format "python efffocal.py {star1_RA} {star1_Dec} {star2_RA}, {star2_Dec}"\033[0m') #Error (red) print
        sys.exit()
    
    #Extract inputs
    star1_RA = float(sys.argv[2]) * np.pi / 180 #Get star1 RA (in radians)
    star1_Dec = float(sys.argv[3]) * np.pi / 180 #Get star1 Dec (in radians)
    star2_RA = float(sys.argv[4]) * np.pi / 180 #Get star2 RA (in radians)
    star2_Dec = float(sys.argv[5]) * np.pi / 180 #Get star2 Dec (in radians)
    
    #Extract camera settings from parameters file
    parameters_file = open(parameters_path, 'r') #Open parameters file
    parameters = json.load(parameters_file) #Load parameters
    
    D = parameters.get("telescope", {}).get("D") #m | Aperture diameter
    epsilon = parameters.get("telescope", {}).get("eps") #Central obscuration (by diameter)
    gain = parameters.get("capture", {}).get("gain") #ADU | Camera gain
    exposure_length = parameters.get("capture", {}).get("exp") #ms | Frame exposure length
    
    #Setup camera
    asi.init(sdk_path) #Initialse ASI SDK
    
    cameras = asi.list_cameras() #Get list of all connected ASI cameras
    if not cameras:
        print('\033[91mError: Camera Not Connected\033[0m') #Error (red) print
        sys.exit()
        
    C = asi.Camera(0) #Set ASI camera
    
    C.set_control_value(asi.ASI_GAIN, gain) #Adjust gain
    C.set_control_value(asi.ASI_EXPOSURE, exposure_length * 10**3) #Adjust exposure (in microseconds)
    C.set_image_type(asi.ASI_IMG_RAW8) #Set 8-bit image format
    C.set_roi_format(roi, roi, 1, asi.ASI_IMG_RAW8) #Set region-of-intrest (must be multiple of 8, centred in camera)
    
    #Take capture
    C.start_video_capture() #Start camera
    frame_buffer = C.capture_video_frame() #Get frame buffer
    image = np.frombuffer(frame_buffer, dtype=np.uint8).reshape((roi, roi)) #Turn frame into 2D image array
    C.stop_video_capture() #Stop camera
    
    #Identify stars
    _, image_binary = cv2.threshold(image, threshold, 255, cv2.THRESH_BINARY) #Create binary image based of brightness threshold
    
    contours, _ = cv2.findContours(image_binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE) #Find contours of stars

    star_positions = [] #Hold centre coordinates of stars
    
    for cnt in contours: #Loop through all contours
        M = cv2.moments(cnt) #Compute contour moments
        
        if M['m00'] != 0: #If area non-zero
            cx = M['m10'] / M['m00'] #Find x-coordinate of centre
            cy = M['m01'] / M['m00'] #Find y-coordinate of centre
            star_positions.append((cx, cy)) #Append centres to array
    
    #Debugging prints if less than two stars
    if len(star_positions) < 2:
        print(f'\033[96mBrightness Threshold = {threshold}\033[0m') #Smaller progress (light-blue) print
        print(f'\033[96mStars Detected = {len(star_positions)}\033[0m') #Smaller progress (light-blue) print
        print(f'\033[96mStar Position = ({round(star_positions[0][0], 2)}, {round(star_positions[0][1], 2)})\033[0m') #Smaller progress (light-blue) print
    
        plt.imshow(image_binary, cmap = 'gray') #Plot image with gray colour map
        plt.title('Brightness Threshold Binary Image') #Title image
        plt.plot(star_positions[0][0], star_positions[0][1], 'bo') #Plot star position
        plt.axis('off') #Hide axes
        plt.show() #Display image
        
        C.close() #Close camera
        sys.exit() #End script
    
    #Find and use wanted separation (closest two: sep_type = 0, furthest two: sep_type = 1)
    if len(star_positions) > 2: #Check if more than two stars detected
        star_seps = [] #Hold star separations
        
        for A, starA in enumerate(star_positions): #Loop through all stars
            for B, starB in enumerate(star_positions): #Loop through all stars again
                if B > A: #Make sure not to check star against itself and not performing duplicate calculation
                    star_seps.append(np.sqrt((starA[0] - starB[0])**2 + (starA[1] - starB[1])**2)) #Find pixel separation
        
        if sep_type == 0: #Use closest two stars (sep_type = 0)
            pix_sep = min(star_seps) #Find smallest separation
        
        else: #Use furthest two stars (sep_type = 1)
            pix_sep = max(star_seps) #Find largest separation
    else: #Exactly two stars present
        pix_sep = np.sqrt((star_positions[0][0] - star_positions[1][0])**2 + (star_positions[0][1] - star_positions[1][1])**2) #Find pixel separation
    
    #Compute pixel scale
    ang_sep = np.arccos(np.sin(star1_Dec) * np.sin(star2_Dec) + np.cos(star1_Dec) * np.cos(star2_Dec) * np.cos(star1_RA - star2_RA)) #Find angular separation
    theta = ang_sep / pix_sep #Find pixel scale
    F = p / theta #Find focal length
    
    #Print results
    print(f'\033[94mPixel Scale = {round(theta * 3600 * 180 / np.pi, 2)}"\033[0m') #Progress (blue) print
    print(f'\033[94mEffective Focal Length = {round(F, 3)}m\033[0m') #Progress (blue) print
    
    #Compute radius values
    if conjugation_distances != []:
        for H in conjugation_distances:
            radius = D * (1 + epsilon) / (4 * H * theta) #Find optimal ring radius
            print(f'\033[96mFor H = {H}m, use r = {round(radius, 2)}px\033[0m') #Smaller progress (light-blue) print
            
    #Disconnect from camera
    C.close() #Close camera
    
    #Optional Debugging prints
    # print(f'\033[96mBrightness Threshold = {threshold}\033[0m') #Smaller progress (light-blue) print
    # print(f'\033[96mStars Detected = {len(star_positions)}\033[0m') #Smaller progress (light-blue) print
    
    # for i, star in enumerate(star_positions): #Loop through all stars
    #     print(f'\033[96mStar{i + 1} Position = ({round(star[0], 2)}, {round(star[1], 2)})\033[0m') #Smaller progress (light-blue) print
        
    # print(f'\033[96mPixel Separation = {round(pix_sep, 2)}\033[0m') #Smaller progress (light-blue) print
    # print(f'\033[96mAngular Separation = {round(ang_sep, 2)}\033[0m') #Smaller progress (light-blue) print

    # plt.imshow(image_binary, cmap = 'gray') #Plot image with gray colour map
    # plt.title('Brightness Threshold Binary Image') #Title image
    # for star in star_positions: #Loop through all stars
    #    plt.plot(star[0], star[1], 'bo') #Plot star positions
    # plt.axis('off') #Hide axes
    # plt.show() #Display image