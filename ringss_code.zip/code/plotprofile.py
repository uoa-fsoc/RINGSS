#Notes:
    #Can take date or sequence folders as path, easy to choose what plots wanted
    #Layers with 0 turbulence are treated as missing

#Import libraries
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
import matplotlib as mpl
import sys
import os
from pathlib import Path
from datetime import datetime
import json
import re

#Optional settings
plot_layer_labels = False #Toggle plotting of labels to identify layers

#Set paths
python = 'C:/Users/adamd/miniconda3/python.exe' #Absolute python.exe path
parameters_path = 'par-ardmore.json' #Relative parameters file path

#Change default plot font
mpl.rcParams['font.family'] = 'Segoe UI'

def set_output_path(input_path):
    date_format = re.compile(r'^\d{4}-\d{2}-\d{2}$') #date folder name format
    
    for parent in [input_path] + list(input_path.parents): #Look through every folder of path
        if date_format.match(parent.name): #Look for matching format
            plots_folder = parent / "Turbulence Profile Plots" #Set plot path
            plots_folder.mkdir(exist_ok=True)  #Create path if doesn't exist 
            
            return plots_folder

def extract_profile_data(prof_path):
    prof_file = open(prof_path, 'r') #Read prof file
    lines = prof_file.readlines() #Seperate lines
    prof_file.close() #Close file

    data = [x.strip() for x in lines[1].split(',')] #Extract and strip data line

    #Format data [Date, Star, Zen, Flux, See2, See, Fsee, Wind, tau0, theta0, scint, rms, prof*8]
    data_formatted = []

    #Convert first value to datetime
    data_formatted.append(datetime.fromisoformat(data[0]))

    #Convert second value to string
    data_formatted.append(data[1])

    #Convert next 10 values to float
    for value in data[2:12]:
        data_formatted.append(float(value))

    #Convert remaining values to a sublist (floats or np.nan)
    layers = []
    
    for value in data[12:]:
        if value.lower() == 'nan': #Deals with "nan" case (missing layer)
            layers.append(np.nan)
        else: #Deals with number case
            if float(value) == 0: #Deals with 0 case (treated as missing layer)
                layers.append(np.nan)  
            else: #Deals with actual value
                layers.append(float(value) * 1e-13)

    data_formatted.append(np.array(layers))

    return data_formatted

def plot_profile(prof_data, Cn2_data, zgrid, prof_path, output_path, save_plots):
    #Get profile name
    parent_folders = prof_path.parents #Divide path into parent folders
    time_name = parent_folders[1].name #Get time name
    sequence_name = parent_folders[0].name #Get sequence name
    profile_name = f'{time_name} - {sequence_name}.png' #Create profile name
    
    in_brackets = re.search(r'\((.*?)\)', time_name)
    
    if in_brackets:
        object_name = in_brackets.group(1) #Get object name
    
    #Create data without nan values (to allow continous lines)
    remove_nans = ~np.isnan(Cn2_data)
    Cn2_plot = Cn2_data[remove_nans]
    Jj_plot = prof_data[12][remove_nans]
    zgrid_plot = zgrid[remove_nans]
    
    #Create figure
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize = (10, 10), sharey = True) #Setup plot and set size
    fig.subplots_adjust(wspace=0) #Remove space between subplots
    
    #Plot Cn2 profile
    ax1.plot(Cn2_plot, zgrid_plot, linewidth = 5, color = 'MediumSlateBlue', solid_joinstyle = 'round', solid_capstyle = 'round') #Plot data
    ax1.set_ylim(-1, 17)
    ax1.set_xscale('log') #Set x-axis to log-scale
    ax1.set_xlabel(r'$\mathbf{C_n^2}$ $\mathbf{[m^{-2/3}]}$', fontsize = 18) #Set x-axis label
    ax1.set_ylabel('Altitude [km]', fontsize = 18, fontweight = 'bold') #Set y-axis label
    
    #Plot Jj profile
    ax2.plot(prof_data[12], zgrid, marker = 'o', markersize = 10, color = 'MediumSlateBlue', linestyle = 'None') #Plot data points
    ax2.plot(Jj_plot, zgrid_plot, linewidth = 5, color = 'MediumSlateBlue') #Plot data lines
    ax2.set_ylim(-1, 17)
    ax2.set_xscale('log') #Set x-axis to log-scale
    ax2.set_xlabel(r'$\mathbf{J_j}$ $\mathbf{[m^{1/3}]}$', fontsize = 18) #Set x-axis label
    
    #Style plots
    for ax in [ax1, ax2]:
        ax.margins(x = 0.15) #Add x-axis padding
        
        ax.set_facecolor('white') #Change colour of plot background
        
        ax.yaxis.set_minor_locator(ticker.AutoMinorLocator()) #Add minor ticks to y-axis
        
        for spine in ax.spines.values(): #Make borders thicker
            spine.set_linewidth(1.5)
        
        ax.tick_params(axis = 'x', which = 'major', width = 1.5, length = 7, labelsize = 14, direction = 'in', top = True, bottom = True) #Put ticks on inside and both sides, also make thicker and longer, also increase text size
        ax.tick_params(axis = 'x', which = 'minor', width = 1.5, length = 3, labelsize = 14, direction = 'in', top = True, bottom = True)
        ax.tick_params(axis = 'y', which = 'major', width = 1.5, length = 7, labelsize = 14, direction = 'in', left = True, right = True)
        ax.tick_params(axis = 'y', which = 'minor', width = 1.5, length = 3, labelsize = 14, direction = 'in', left = True, right = True)
    
    #Add layer labels (placed to avoid overlap with data)
    if plot_layer_labels == True:
        label_dist = 0.15
        
        for i, (J_value, z_value) in enumerate(zip(prof_data[12], zgrid)):
            if np.isnan(J_value):
                continue
            
            if 0 < i < len(prof_data[12]) - 1:
                prev_J, next_J = prof_data[12][i-1], prof_data[12][i+1]
                prev_z, next_z = zgrid[i-1], zgrid[i+1]
                
                slope_in = (z_value - prev_z) / (J_value - prev_J) if (J_value - prev_J) != 0 else 0
                slope_out = (next_z - z_value) / (next_J - J_value) if (next_J - J_value) != 0 else 0
                
                avg_slope = (slope_in + slope_out) / 2
            else:
                avg_slope = 0
            
            if avg_slope > 0:
                x_offset = J_value * (1 + label_dist)
                y_offset = z_value + label_dist
                ha, va = 'left', 'bottom'
            else:
                x_offset = J_value * (1 - label_dist)
                y_offset = z_value - label_dist
                ha, va = 'right', 'top'
            
            ax2.text(x_offset, y_offset, f'$J_{{{i}}}$', fontsize = 14, ha = ha, va = va)
        
    #Add list of other profile values
    values = [prof_data[4], prof_data[5], prof_data[6], prof_data[7], prof_data[8], prof_data[9], prof_data[2], prof_data[10], prof_data[11]] #Wanted values
    names = ['$\\epsilon_{\\text{diff}}$', '$\\epsilon_{\\text{scint}}$', '$\\epsilon_{\\text{free}}$', '$V_2$', '$\\tau_0$', '$\\theta_0$', '$\\theta_z$', 'scint', 'rms'] #Corresponding value names
    units = ['\"', '\"', '\"', '$ms^{-1}$', '$ms$', '\"', '$^\\circ$', '', ''] #Corresponding units

    display_lines = [f'{name} = {value}{unit}' for name, value, unit in zip(names, values, units)]
    display_text = '\n'.join(display_lines)
    
    fig.text(0.92, 0.24, display_text, fontsize = 16, ha = 'left', va = 'center', bbox = dict(facecolor = 'white', alpha = 0.8, edgecolor = 'black', boxstyle = 'round ,pad = 0.3', linewidth = 1.5)) #Add list next to plot
    
    #Save or display plot, based on call
    if save_plots == True: #Check if coming from maintaincapture5.py
        profile_path = output_path / profile_name #Set profile path
        plt.savefig(profile_path, bbox_inches = 'tight') #Save plot (removing extra white-space)
        plt.close(fig) #Close plot
    else:
        plt.show() #Display plot

if __name__ == "__main__": #Check if python script is run directly
    if len(sys.argv) < 2: #Make sure correct inputs are given
        print('\033[91mError: Command should have format "python plotprofile.py {any_output_path}"\033[0m') #Error (red) print
        sys.exit()
        
    if len(sys.argv) > 2 and sys.argv[2].lower() == 'auto': #Check if coming from maintaincapture5.py
        save_plots = True
    else:
        save_plots = False
  
    #Assign input fields
    input_path = Path(os.path.relpath(os.path.abspath(sys.argv[1]), os.path.abspath(os.path.dirname(__file__)))) #Find relative path
    
    #Extract z-grid from parameters file
    parameters_file = open(parameters_path, 'r') #Open parameters file
    parameters = json.load(parameters_file) #Extract parameters content
    parameters_file.close() #Close parameters file

    zgrid = np.array(parameters['profrest']['zgrid']) / 10**3 #Extract z-grid and set units to km
    
    output_path = set_output_path(input_path) #Create plot output path
    prof_paths = list(input_path.rglob("*.prof")) #Find all profile paths
    
    #Create all profiles
    for prof_path in prof_paths:
        prof_data = extract_profile_data(prof_path) #Extract data from profiles
        
        #Convert to Cn2 profile
        Cn2_data = np.array([])
        
        for i in range(len(prof_data[12])):
            if i == len(prof_data[12]) - 1: #Special case for top layer
                dh = zgrid[i] * 2 #Assume layer thickness is twice height
            else: #Main case
                dh = zgrid[i + 1] - zgrid[i] #Compute layer thickness
            
            Cn2 = prof_data[12][i] / (dh * 10**3) #Compute Cn2 (converting z-grid back to m first)
            Cn2_data = np.append(Cn2_data, Cn2)
        
        plot_profile(prof_data, Cn2_data, zgrid, prof_path, output_path, save_plots) #Create and save profile plots
    
    plt.close('all') #Make sure all scripts are closed
    print('\033[92mAll turbulence profiles succesful plotted\033[0m') #Success (green) print