# Import libraries
import sys
from pathlib import Path
import os
import json
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter
from matplotlib.lines import Line2D

#Optional settings
plot_aberrations = False #Toggle aberration plotting

def load_weight_file(file_path):
    with open(file_path, 'r') as f:
        weight = json.load(f)
    z = np.array(weight["z"])
    nz = len(z)
    nm = len(weight["wt0"][0])
    wt = np.reshape(np.array(weight["wt0"]), (nz, nm))
    return z, wt, nm

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('\033[91mError: Command should have format "python plotweights.py {weights_aber_file}"\033[0m')
        sys.exit()

    # Hardcoded path for weights_perf
    weights_perf_path = Path("weights.json")

    # Path for weights_aber from command-line argument
    weights_aber_path = Path(os.path.relpath(os.path.abspath(sys.argv[1]), os.path.abspath(os.path.dirname(__file__))))

    # Load weights
    z_perf, wt_perf, nm_perf = load_weight_file(weights_perf_path)
    z_aber, wt_aber, nm_aber = load_weight_file(weights_aber_path)

    # Maximum number of angular modes to show
    max_coeffs = 9 #nm_perf is all
    coeff_indices = range(max_coeffs)

    # Plot weighting functions
    
    if plot_aberrations == True:
        fig, (ax1, ax2) = plt.subplots(
            1, 2,
            figsize=(14, 6),
            gridspec_kw={'width_ratios': [2.5, 1]}  # ax1 is 2.5× wider than ax2
        )
    else:
        fig, ax1 = plt.subplots(figsize=(10, 6))
    
    # Define color cycle
    colors = plt.cm.tab10.colors  # Up to 10 colors

    for idx, j in enumerate(coeff_indices):
        color = colors[idx % len(colors)]
        # Dashed line for Perf
        ax1.plot(z_perf / 1000, wt_perf[:, j + 1], linestyle='-', color=color, alpha=0.5, linewidth=2.5, label=f"{j+1}")
        # Solid line for Aber
        ax1.plot(z_aber / 1000, wt_aber[:, j + 1], linestyle='--', color=color, linewidth=2.5)
        
    # Grab existing handles and labels
    handles, labels = ax1.get_legend_handles_labels()
    
    # Create new handles with full opacity for the legend
    opaque_handles = []
    for h in handles:
        new_h, = ax1.plot([], [], color=h.get_color(), linewidth=h.get_linewidth(), label=h.get_label())
        opaque_handles.append(new_h)
    
    # Create legend with opaque handles
    ax1.legend(handles=opaque_handles, labels=labels,
              title=r"Angular Mode ($m$)",
              title_fontsize=14,
              fontsize=12,
              frameon=False,
              ncol=2)

    # Log-log scaling
    ax1.set_xscale("log")
    ax1.set_yscale("log")

    # Axis labels
    ax1.set_xlabel("Altitude [km]", fontsize=16)
    ax1.set_ylabel(r"Weight [m$^{-1/3}$]", fontsize=16)

    # Format x-axis
    ax1.xaxis.set_major_formatter(ScalarFormatter())
    ax1.xaxis.get_major_formatter().set_scientific(False)
    ax1.tick_params(axis='both', which='major', labelsize=14)

    # Create legend with opaque handles (angular modes)
    legend_modes = ax1.legend(handles=opaque_handles, labels=labels,
                             title=r"Angular Mode ($m$)",
                             title_fontsize=14,
                             fontsize=12,
                             frameon=False,
                             ncol=2)
    
    # Add the first legend to the axes explicitly
    ax1.add_artist(legend_modes)
    
    # Create legend for line styles (Perf/Aber) in bottom left
    line_style_legend = [
        Line2D([0], [0], color='black', linestyle='-', linewidth=2.5, label='Perfect Weights'),
        Line2D([0], [0], color='black', linestyle='--', linewidth=2.5, label='Aberration Weights')
    ]
    ax1.legend(handles=line_style_legend, loc='lower left', fontsize=12, frameon=False)
    
    if plot_aberrations == True:
        #Extract aberration amplitudes (optional)
        aber_path = weights_aber_path.parent / 'aberrations.json' #Get aberrations path
        aber_file = open(aber_path, 'r') #Open aberrations file
        aber_data = json.load(aber_file) #Extract abeerations data
    
        zernike = np.arange(4, 11) #Corresponding Zernike terms
        zampl = np.round(np.array(aber_data["zampl"]), 2) #Extract list of amplitudes (with 2 decimal places)
        
        #Plot aberration amplitudes (optional)
        amp_thresh = 0.5 #rad | Aberration amplitude negligible threshold
        
        bars = ax2.bar(zernike, np.abs(zampl), color='steelblue', edgecolor='black')
        
        # Add signed labels above bars
        for bar, value in zip(bars, zampl):
            height = bar.get_height()
            ax2.text(
                bar.get_x() + bar.get_width()/2,
                height + 0.02 * max(np.abs(zampl)),
                f'{value:+.2f}',
                ha='center', va='bottom', fontsize=10
            )
        
        # Red dashed threshold line
        ax2.axhline(amp_thresh, color='red', linestyle='--', linewidth=2, label='Negligible Threshold')
        
        # Axis labels and title
        ax2.set_xlabel('Zernike Term', fontsize=16)
        ax2.set_ylabel('Amplitude [|rad|]', fontsize=16)
        ax2.set_xticks(zernike)
        xtick_labels = [f"$Z_{{{i}}}$" for i in zernike]
        ax2.set_xticks(zernike)
        ax2.set_xticklabels(xtick_labels)
        ax2.tick_params(axis='both', which='major', labelsize=14)
        ax2.set_ylim(0, max(np.abs(zampl)) * 1.25)
        ax2.legend(frameon=False, fontsize=14, loc='upper right')
        ax2.grid(axis='y', linestyle='--', alpha=0.6)
        
    plt.tight_layout(w_pad=3.0)
        
    #Save or display plot, based on call
    if len(sys.argv) > 2 and sys.argv[2].lower() == 'auto': #Check if coming from createweights.py
        date = __import__('datetime').datetime.now(__import__('datetime').timezone.utc).strftime("%d-%m-%Y")
        output_path = Path(weights_aber_path).parent / f'{date} Weighting Functions.png'
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
    else:
        plt.show()