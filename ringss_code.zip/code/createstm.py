#Notes:
    #Run this script once all the statstical moments (from cube2.py) have been produced
    #Is output as .stm file, but is essentially a txt file
    #To use, open anaconda prompt and enter 'cd "/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Logging Version (close to Toko)/code_modified"', then python createstm.py "../outputs/{folder}"'

#Import libraries
import os
import glob
import numpy as np
import json
import sys
import re

lines = [] #Empty list which is filled with lines to write to stm file

def generate_cube_info_line(json_file, num_avg): #'O' prefixed line
    data = json.load(open(json_file, 'r')) #Get cube information
    
    #Set parameter values from json file
    date = data['cubepar']['date']
    hr = data['cubepar']['star']
    frames_per_cube = data['cubepar']['nz']
    exposure_time = float(data['cubepar']['texp']) * 1000 #Converted to ms
    camera_gain = data['cubepar']['gain']
    averaged_cubes = num_avg
    pixels = data['cubepar']['nx']
    
    cube_info = ['O', date, hr, frames_per_cube, exposure_time, camera_gain, averaged_cubes, pixels] #Format cube information
    
    cube_info_joined = ','.join(map(str, cube_info)) #Join cube information
    lines.append(cube_info_joined) #Add cube information to lines

def generate_moments_line(json_files, single_number): #'m' and 'M' prefixed lines
    avg_moments_array = np.zeros(74) #Create empty average moments array, 74 total elements
    
    for file in json_files:
        data = json.load(open(file, 'r')) #Open json file
        
        #Set single parameter values from json file
        date = data['cubepar']['date']
        hr = data['cubepar']['star']
        
        #Get single moments from json file, stored as numpy array
        single_moments_array = np.concatenate((
            np.array(data['image']['impar']), #12 elements
            np.array(data['image']['noisepar']), #4 elements
            np.array(data['moments']['var']), #21 elements
            np.array(data['moments']['cov']), #21 elements
            np.array([data['moments']['rnoise']]), #1 element
            np.array([data['moments']['rvar']]), #1 element
            np.array(data['moments']['mcoef']))) #14 elements
        
        avg_moments_array += single_moments_array #Add to average array
        
        if single_number == '0' or single_number == '-1' or single_number == '-2':
            single_moments = ['m', date, hr, ','.join(map(str, single_moments_array))] #Format single moments and convert numpy array to formatted string
            single_moments_joined = ','.join(map(str, single_moments)) #Join single moments
            lines.append(single_moments_joined) #Add single moments to lines
        
    avg_data = json.load(open(json_files[0], 'r')) #Extract date and hr number from first json file
     
    #Set average parameter values from json file
    avg_date = avg_data['cubepar']['date']
    avg_hr = avg_data['cubepar']['star']
    averaged_cubes = len(json_files)
        
    avg_moments_array = avg_moments_array / len(json_files) #Turn average moments into actual average
    
    avg_moments = ['M', avg_date, avg_hr, averaged_cubes, ','.join(map(str, avg_moments_array))] #Format average moments and convert numpy array to formatted string
    avg_moments_joined = ','.join(map(str, avg_moments)) #Join average moments
    lines.append(avg_moments_joined) #Add single moments to lines
    
def write_stm_file(indir, outdir, single_number, specific_capture_numbers): #'m' prefixed line
    if single_number == '-2':
        basename = os.path.basename(os.path.normpath(folddir)) #Create main name to identify files

    elif single_number == '-1':
        basename = os.path.basename(os.path.normpath(os.path.dirname(folddir))) #Create main name to identify files

    elif single_number == '0':
        basename = os.path.basename(os.path.normpath(indir)) #Create main name to identify files
        
        if specific_capture_numbers != None:
            basename = basename[:-12] + ' ' + sys.argv[2] #Removes ' ((moments))' and adds combination identifier to basename
            
    else:
        filename = os.path.basename(indir)
        basename, ext = os.path.splitext(filename) #Create main name to identify files, without '.json'
    
    #file_name = outdir + basename + '.stm' #Create name for stm file
    file_name = os.path.join(outdir, basename + '.stm')
    
    stm_file = open(file_name, 'w') #Create and open stm file

    for line in lines:
        stm_file.write(line + '\n') #Write all lines to stm file
    
if __name__ == "__main__": #Check if python script is run directly
    #print('\033[94mGathering data and parameters \033[95m(createstm.py)\033[0m') #Progress (blue) print and script (purple) print
    #print("Generating stm file...")
    
    if len(sys.argv) < 2: #Make sure correct inputs are given
        print("Usage: python createstm.py {folddir}")
  
    #Assign input fields
    folddir = sys.argv[1]
    
    if len(sys.argv) > 2: #Check coming from autoprocessing.py and adjust accordingly
        if sys.argv[2] == 'weights': #Check if from createweights.py
            single_number = '-2'
            specific_capture_numbers = 0
            
            json_files = [folddir + '.json'] #Get the single watned json file
            
            outputdir = os.path.dirname(folddir) #Sets output path to object folder
    
        elif sys.argv[2] == 'auto4': #Check if from autoprocessing4.py
            single_number = '-1'
            specific_capture_numbers = 0
            
            glob_path = glob.escape(os.path.abspath(folddir)) #Path that uses escape (glob uses sqaure brackets itself)
            json_files = glob.glob(os.path.join(glob_path, '*.json')) #Get all json files in folder
            
            outputdir = os.path.dirname(folddir) #Sets output path to object folder (one level up)
        
        elif '((' in sys.argv[2]: #Check if combination
            single_number = '0'
        
            #Get all input json files
            glob_path = glob.escape(os.path.abspath(folddir)) #Path that uses escape (glob uses sqaure brackets itself)
            json_files = glob.glob(os.path.join(glob_path, '*.json')) #Get all json files in folder
        
            if sys.argv[2] != '((all))': #Check if all captures used
                specific_capture_numbers = [int(num) for num in (sys.argv[2])[2:-2].split(',')] #Split string of folder numbers into list
                specific_capture_numbers.sort() #Put list in numerical order
                
                keep_json_files = []
                
                for json_file in json_files: #Filter json files
                    filename = os.path.basename(json_file) #Get basename, with '.json'
                    basename, ext = os.path.splitext(filename) #Create main name to identify files, without '.json'
                    capture_number = int(re.search(r'\(\((\d+)\)\)', basename).group(1)) #Extract capture number
                    
                    if capture_number in specific_capture_numbers: #Keep json file if in list
                        keep_json_files.append(json_file)
                
                json_files = keep_json_files
            else:
                specific_capture_numbers = 0
                
            outputdir = os.path.dirname(os.path.dirname(folddir)) #Sets output path to object folder (two levels up)
        else: #Otherwise must be single
            specific_capture_numbers = None
        
            single_number = sys.argv[2]
            json_files = [folddir]
            
            #Find output path
            normalised_path = os.path.normpath(folddir) #Nomarlised path
            path_parts = normalised_path.split(os.sep) #Split path into folders
            object_name = path_parts[-4] #Extract capture name from path
            singles_path = os.path.dirname(os.path.dirname(folddir)) #Extract singles folder from path
            outputdir = os.path.join(singles_path, object_name + ' ((stms))') #Puts output path together
    else:
        single_number = '0'
        specific_capture_numbers = None
    
        #Get all input json files
        glob_path = glob.escape(os.path.abspath(folddir)) #Path that uses escape (glob uses sqaure brackets itself)
        json_files = glob.glob(os.path.join(glob_path, '*.json')) #Get all json files in folder
        
        outputdir = folddir + '/'
    
    def extract_time(filename):
        json_basename = os.path.basename(filename) #Extracts just file name from path
        
        match = re.search(r'(\d{2}_\d{2}_\d{2})(?=\.json$)', json_basename) #Extracts time from the file name
        
        #Checks to see if found
        if match:
            time = match.group(1)
            return tuple(map(int, time.split('_'))) #Turns into tuple that can be ordered
        else: 
            return (0, 0, 0) #Sends to start of list

    json_files.sort(key=extract_time) #Orders the json files

    #Add content to writing list
    generate_cube_info_line(json_files[0], len(json_files))
    generate_moments_line(json_files, single_number)
    
    write_stm_file(folddir, outputdir, single_number, specific_capture_numbers)

    #print("stm file sucessfully created!")