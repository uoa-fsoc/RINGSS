#Notes:
    #This script assumes the star is already close to the roi centre and defocused into a ring of any size



#Import libraries
import zwoasi as asi
from alpaca.focuser import Focuser
import numpy as np
import sys
import os
from datetime import datetime, timezone
from astropy.io import fits
import time
import json
import matplotlib.pyplot as plt

#Optional settings
drift_plots = False #Toggle display of plots showing star drift across the capture sequence
display_roi = 64 #Region of interest shown in drifting plots

#Set paths
python = 'C:/Users/adamd/miniconda3/python.exe' #Absolute python.exe path
parameters_path = 'par-ardmore.json' #Relative parameters file path
data_path = 'C:/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/data' #Absolute main data folder path
sdk_path = 'C:/Users/adamd/Desktop/PHYSICS 789/ASI SDK/lib/x64/ASICamera2.dll' #Absolute ASI SDK path

#Set ring adjustment parameters
radius_threshold = 0.5 #pixels | Amount off ring radius that is allowed before moving focuser (optimal radius +- radius_threshold)
adjustment_step = 50 #micrometeres | Initial step size of focuser to adjust ring radius
avg_frames = 50 #frames | Amount of frames captured for determining ring radius

def get_ring_dimensions(camera, avg_frames, centres = False):
    capture = [] #Array to store captured frames
    
    C.start_video_capture() #Start video capture (fastest way to take multiple frames)

    for i in range(avg_frames):
        #Get single frame
        frame_buffer = C.capture_video_frame() #Collect capture buffer (1D array)
        frame = np.frombuffer(frame_buffer, dtype=np.uint16).reshape((roi, roi)) #Format capture into 2D numpy array
    
        capture.append(frame) #Add frame to capture array   
    
    C.stop_video_capture() #End video capture
        
    #Calculate ring radius and width
    nz, ny, nx = np.array(capture).shape  # e.g., 2000 frames of 64x64 pixels
    
    # Average the first nstart frames to get a representative ring image
    nstart = 50
    imav = np.average(capture[0:nstart], axis=0)  # (64, 64) average image
    
    # Create coordinate grids centered around the image center
    i = np.indices((nx, nx))
    yy = i[0] - nx / 2  # vertical distance from center
    xx = i[1] - nx / 2  # horizontal distance from center
    
    # Convert Cartesian coordinates to polar
    r = np.sqrt(np.square(xx) + np.square(yy))  # radial distance from center
    phi = np.arctan2(yy, xx)  # angle (radians) from center
    
    # Prepare radial and angular masks
    m = 20       # max angular frequency for Fourier components
    nsect = 8    # number of angular sectors to divide the ring
    rwt = np.zeros((nsect, nx, nx))  # weights for computing sector-wise radius
    fwt = np.zeros((nsect, nx, nx))  # binary masks for flux in each sector
    sect = 2. * np.pi / nsect        # angular width of each sector (radians)
    
    # Define sector masks in polar space
    for j in range(nsect):
        sector = (phi >= (sect * (j - nsect / 2))) & (phi < (sect * (j + 1 - nsect / 2)))
        fwt[j] = sector.astype(float)
        rwt[j] = sector * r  # multiply by radius to use in weighted sum
    
    # Diagnostic image to test radial mask layout (optional visualization aid)
    test = np.zeros((nx, nx))
    for j in range(nsect):
        test += rwt[j] * (j + 1)
    
    # Compute angle (in radians) for each sector center
    phisect = sect * (np.arange(nsect, dtype=float) - nsect / 2 + 0.5)
    xsect, ysect = np.cos(phisect), np.sin(phisect)  # unit vectors for each sector
    
    # Estimate background level from left/right edges of image
    backgr = np.median([imav[:, 0], imav[:, nx - 1]])
    tmp = imav - backgr  # subtract background from averaged image
    
    # Estimate total intensity and flux centroid (center of light)
    itot = np.sum(tmp)
    xc = np.sum(tmp * xx) / itot
    yc = np.sum(tmp * yy) / itot
    
    # Rough shift to center the ring by integer pixel values
    imavcent = np.roll(tmp, (int(-xc), int(-yc)), axis=(1, 0))
    
    # Compute preliminary radii in each angular sector
    radii = np.zeros(nsect)
    for j in range(nsect):
        radii[j] = np.sum(imavcent * rwt[j]) / np.sum(imavcent * fwt[j])
    
    # Compute small offset to more accurately center the ring
    dx1 = np.sum(radii * xsect) / nsect * 2.3
    dy1 = np.sum(radii * ysect) / nsect * 2.3
    xc += dx1
    yc += dy1  # refined center
    
    # Apply sub-pixel shift via Fourier shift theorem
    arg = 2 * np.pi * (dx1 * xx + dy1 * yy) / nx
    imavcent = np.fft.ifft2(np.fft.fft2(imavcent) *
                            np.fft.fftshift(np.cos(arg) + np.sin(arg) * 1j)).real
    
    # Recalculate sector radii with improved centering
    for j in range(nsect):
        radii[j] = np.sum(imavcent * rwt[j]) / np.sum(imavcent * fwt[j])
    radpix = np.sum(radii) / nsect  # average ring radius (pixels)
    
    # Estimate ring width by thresholding at 10% of max and measuring radial variance
    tmp = imavcent - 0.1 * np.max(imavcent)
    tmp *= (tmp > 0)  # keep only values above threshold
    radvar = np.sum(tmp * (r - radpix) ** 2) / np.sum(tmp)
    rwidth = pow(radvar, 0.5) * 2.35  # FWHM assuming Gaussian shape
    
    # Refine background using pixels well outside the ring
    backgr += np.median(imavcent * (r > 1.5 * radpix))
    
    # Create a binary ring mask (annulus) for analysis
    drhopix = 1.5 * rwidth  # mask half-width
    ringmask = (r >= radpix - drhopix) & (r <= radpix + drhopix)
    
    # Construct the basis matrix for projection (masks × pixels)
    ncoef = 2 * nsect + 2 * (m + 1)
    maskmat = np.zeros((ncoef, nx * nx))
    
    # Add radial and angular sector masks to the matrix
    for j in range(nsect):
        maskmat[j, :] = np.ndarray.flatten(rwt[j] * ringmask)  # radius weighting
        maskmat[j + nsect, :] = np.ndarray.flatten(fwt[j] * ringmask)  # flux
    
    # Add angular Fourier basis functions (cos and sin components)
    for j in range(m + 1):
        tmp = np.cos(phi * j) * ringmask
        if j > 0:
            cwt = tmp - np.sum(tmp) / nx / nx  # remove average value
        else:
            cwt = tmp
        tmp = np.sin(phi * j) * ringmask
        swt = tmp - np.sum(tmp) / nx / nx
        maskmat[2 * nsect + j, :] = np.ndarray.flatten(cwt)
        maskmat[2 * nsect + m + 1 + j, :] = np.ndarray.flatten(swt)
    
    # === Main loop to process each frame in the cube ===
    rad = np.zeros(nz)  # will store estimated ring radius per frame
    x0, y0 = xc, yc     # initial center coordinates
    
    for i in range(nz):
        tmp = capture[i] - backgr  # subtract background
        arg = 2 * np.pi * (x0 * xx + y0 * yy) / nx  # phase shift
        tmp = np.fft.ifft2(np.fft.fft2(tmp) * np.fft.fftshift(np.cos(arg) + np.sin(arg) * 1j)).real
    
        # Project frame onto basis masks to extract coefficients
        c = np.dot(maskmat, np.ndarray.flatten(tmp))
    
        # Normalize radii by total flux in each sector
        c[0:nsect] = c[0:nsect] / c[nsect:2 * nsect]
        radii = c[0:nsect]
        dr = np.sum(radii) / nsect
    
        # Estimate sub-pixel shift based on sector radii
        dx = np.sum(radii * xsect) / nsect * 2.3
        dy = np.sum(radii * ysect) / nsect * 2.3
        x0 += dx
        y0 += dy
    
        rad[i] = dr  # save current frame's average ring radius
    
    # After loop, calculate overall mean radius across frames
    meanrad = np.mean(rad)
    
    if centres == True:
        return meanrad, rwidth, x0, y0 #return average radius and ring width and centres
    else:
        return meanrad, rwidth  #return average radius and ring width
    
def optimise_ring(C, F, inital_radius, print_final = False):
    current_radius = inital_radius #Set initial current radius
    current_step = adjustment_step #Set initial current step size
    
    while True: #Constantly reduce step size until as close to optimal as possible
        if current_radius < optimal_radius: #Figure out if we need to make radius smaller or larger
            initial_direction = -1
        else:
            initial_direction = 1
            
        current_direction = initial_direction
    
        while current_direction == initial_direction: #Get as close as possible with current step size
            F.Move(F.Position + int(current_step * initial_direction)) #Move focuser clockwise by correction step
            while F.IsMoving == True: #Wait for focuser to stop moving
                pass
            #time.sleep(1) #REMOVE if not needed
            
            previous_radius = current_radius #Set previous radius
            current_radius, current_width = get_ring_dimensions(C, avg_frames) #Get current ring radius and width
            if current_radius < optimal_radius: #Figure out if we need to make radius smaller or larger
                current_direction = -1
            else:
                current_direction = 1
        
        if np.abs(current_radius - optimal_radius) > np.abs(previous_radius - optimal_radius):
            F.Move(F.Position - int(current_step * initial_direction)) #Move focuser counter-clockwise by correction step, undo last step as made gap larger
            while F.IsMoving == True: #Wait for focuser to stop moving
                pass
            #time.sleep(1) #REMOVE if not needed
        
        if current_step == 1: #Check if smallest step used
            break #End loop if smallest step has been used
        
        current_step = int(np.ceil(current_step / 3)) #Reduce current step size
    
    current_radius, current_width = get_ring_dimensions(C, avg_frames) #Get current ring radius and width
    
    if current_radius < optimal_radius - radius_threshold or optimal_radius + radius_threshold < current_radius:
        print(f'\033[33mWarning: Ring radius cannot reach optimal, r = {current_radius}, dr = {current_width}\033[0m') #Error (red) print
    
    elif print_final == True:
        print(f'\033[96mr = {current_radius}, dr = {current_width}\033[0m') #Smaller progress (light-blue) print
    
def take_data_capture(C, object_name, hr, data_folder, object_time, aberration = False):
    #Get time
    timestamp = datetime.now(timezone.utc) #Get current time in UTC+0
    iso_timestamp = timestamp.isoformat() #Put timestamp in ISO format
    
    #Take capture
    capture = [] #Array to store captured frames
    
    C.start_video_capture() #Start video capture (fastest way to take multiple frames)

    for i in range(frames):
        #Get single frame
        frame_buffer = C.capture_video_frame() #Collect capture buffer (1D array)
        frame = np.frombuffer(frame_buffer, dtype=np.uint16).reshape((roi, roi)) #Format capture into 2D numpy array
    
        capture.append(frame) #Add frame to capture array   
    
    C.stop_video_capture() #End video capture
    
    #Set output folder
    date_folder = timestamp.strftime('%Y-%m-%d') #Extract date from timestamp
    time_folder = timestamp.strftime('%H-%M-%S') #Extract time from timestamp
    
    if aberration == True: #Check if captures should be saved under aberrations
        output_folder = os.path.join(data_folder, date_folder, 'Aberrations', f'{object_time} ({object_name})', time_folder) #Set full output folder path
    else:
        output_folder = os.path.join(data_folder, date_folder, f'{object_time} ({object_name})', time_folder) #Set full output folder path
    
    os.makedirs(output_folder, exist_ok=True) #Create all output folders (if needed)
    
    #Create headers and save capture
    object_name_HR = object_name + ' (' + hr + ')'
    
    for i, frame in enumerate(capture):
        hdu = fits.PrimaryHDU(frame) #Set FITS image
        header = hdu.header
        
        #Header setup
        header['OBJECT'] = (object_name_HR, 'name (HR)')
        header['DATE-OBS'] = (iso_timestamp, 'capture start') #Add DATE-OBS in header
        header['EXPTIME'] = (exposure_length * 10**-3, 'seconds') #Add EXPOSURE in header (in seconds)
        header['GAIN'] = gain #Add GAIN in header
        
        fits_file = os.path.join(output_folder, f'{object_name}_{i+1:04d}.fits') #Add frame name
        hdu.writeto(fits_file, overwrite=True) #Save frame

#Script start via command line
if __name__ == "__main__": #Check if python script is run directly
    if len(sys.argv) < 3:
        print('\033[91mError: Command should have format "python takecapture.py {object_name} {hr_number} {optional:aber}"\033[0m') #Error (red) print
        sys.exit()
    
    #Extract target information from input
    object_name = sys.argv[1] #Get object name
    hr = sys.argv[2] #Get HR number
    
    aberration = False #Set default for aberrations to false
    
    if len(sys.argv) > 3:
        if sys.argv[3] == 'aber':
            aberration = True #Set aberrations to true if coming from weight creation
    
    parameters_file = open(parameters_path, 'r') #Open parameters file
    parameters = json.load(parameters_file) #Load parameters
    
    #Extract camera and ring settings from parameters file
    optimal_radius = parameters.get("telescope", {}).get("ringradpix") #pixels | Ring radius that we are aimming for
    capture_info = parameters.get("capture", {}) #Extract capture information
    sequence_length = capture_info.get("seq") #Number of captures to take in sequence
    frames = capture_info.get("frames") #Number of frames take per capture
    exposure_length = capture_info.get("exp") #ms | Expsoure length for single frame
    gain = capture_info.get("gain") #Camera gain
    roi = capture_info.get("roi") #Region-of-intrest for capture (must be multiple of 8, centred in camera)

    print('\033[91mSetting up camera and focuser\033[0m') #Progress (blue) print

    #Setup camera
    asi.init(sdk_path) #Initialse ASI SDK
    
    cameras = asi.list_cameras() #Get list of all connected ASI cameras
    if not cameras:
        print('\033[91mError: Camera Not Connected\033[0m') #Error (red) print
        sys.exit()
        
    C = asi.Camera(0) #Set ASI camera
    
    C.set_control_value(asi.ASI_GAIN, gain) #Adjust gain
    C.set_control_value(asi.ASI_EXPOSURE, exposure_length * 10**3)  #Adjust exposure (in microseconds)
    C.set_image_type(asi.ASI_IMG_RAW16) #Set 16-bit image format
    C.set_roi_format(roi, roi, 1, asi.ASI_IMG_RAW16) #Set region-of-intrest (must be multiple of 8, centred in camera)
    C.set_control_value(asi.ASI_HIGH_SPEED_MODE, 1) #Turn on high-speed mode
    
    #Setup focuser
    F = Focuser('localhost:11111', 0) #Set focuser device path
    F.Connect() #Connect to focuser
        
    #Set to optimal ring radius
    print('\033[94mSetting ring radius to optimal\033[0m') #Progress (blue) print
    
    current_radius, current_width = get_ring_dimensions(C, avg_frames) #Get current ring radius and width for initial adjustment
    optimise_ring(C, F, current_radius, True) #Optimise ring radius
    
    #Take captures while constantly maintaing ring radius
    print('\033[94mInitiating capture set with ring radius maintenance\033[0m') #Progress (blue) print
    timestamp = datetime.now(timezone.utc) #Get current time in UTC+0
    date_folder = timestamp.strftime('%Y-%m-%d') #Extract date from timestamp
    object_time = timestamp.strftime('%H-%M-%S') #Extract time from timestamp
    data_folder = os.path.relpath(os.path.abspath(data_path), os.path.abspath(os.path.dirname(__file__))) #Set relative path to data folder
    object_path = os.path.join(data_folder, date_folder, f'{object_time} ({object_name})') #Write object path
    output_path = os.path.join(data_folder, '../outputs5/', date_folder, f'{object_time} ({object_name})') #Write output path
    
    ring_positions = [] #Hold centre position of rings at different times
    
    for i in range(sequence_length):
        if i == 0 or i == sequence_length - 1: #Record centres if first or last capture, to later compute drifting
            current_radius, current_width, centre_x, centre_y = get_ring_dimensions(C, avg_frames) #Get current ring radius and width along with ring position
            
            current_time = time.time() #Get current time
            
            ring_positions.append([centre_x, centre_y, current_time]) #Add position-time to list
        else:
            current_radius, current_width = get_ring_dimensions(C, avg_frames) #Get current ring radius and width along
        
        take_data_capture(C, object_name, hr, data_path, object_time, aberration) #Take single data capture
    
        if current_radius < optimal_radius - radius_threshold or optimal_radius + radius_threshold < current_radius: #Check if radius outside threshold of optimal value
           optimise_ring(C, F, current_radius, True) #Optimise ring radius
    
    #Disconnect from camera and focuser
    C.close() #Close camera
    F.Disconnect() #Disconnect from focuser
    
    print('\033[92mCapture set completed\033[0m') #Success (green) print
    
    if drift_plots == True: #Calculate drift and generate plots if wanted
        #Find drift rate
        drift_distance = np.sqrt((ring_positions[1][0] - ring_positions[0][0])**2 + (ring_positions[1][1] - ring_positions[0][1])**2) #px | Get centre difference
        dirft_time = (ring_positions[1][2] - ring_positions[0][2]) / 60 #min | Get time difference
        drift_speed = drift_distance / dirft_time #px/min | Get drift speed
        
        #Plot centres with drifting direction
        fig, ax = plt.subplots(figsize=(6, 6)) #Make figure of equal width and height

        roi_centre = 64 / 2 #Find roi centre
        display_centre = display_roi / 2 #Find display centre

        #Set axes limits
        ax.set_xlim(roi_centre - display_centre, roi_centre + display_centre)
        ax.set_ylim(roi_centre - display_centre, roi_centre + display_centre)

        #Overlay pixel grid
        ax.set_xticks(range(int(roi_centre - display_centre), int(roi_centre + display_centre) + 1)) #Set pixel width
        ax.set_yticks(range(int(roi_centre - display_centre), int(roi_centre + display_centre) + 1)) #Set pixel height
        ax.grid(True, color = '#d3d3d3', linestyle = '-', linewidth = 0.5) #Set grid style
        ax.set_xticklabels([]) #Remove x-axis tick labels
        ax.set_yticklabels([]) #Remove y-axis tick labels
        ax.tick_params(left=False, bottom=False) #Prevent ticks outside plot

        ax.plot([roi_centre - display_centre, roi_centre + display_centre, roi_centre + display_centre, roi_centre - display_centre, roi_centre - display_centre], [roi_centre - display_centre, roi_centre - display_centre, roi_centre + display_centre, roi_centre + display_centre, roi_centre - display_centre], color = 'black', linewidth = 2, zorder = 1) #Add display outline

        ax.scatter(ring_positions[0][0], ring_positions[0][1], color = 'blue', edgecolor = 'black', linewidth = 1.8, s = 120, zorder = 30) #Plot start centre
        ax.scatter(ring_positions[1][0], ring_positions[1][1], color = 'blue', edgecolor = 'black', linewidth = 1.8, s = 120, zorder = 30) #Plot end centre
        line = ax.plot([ring_positions[0][0], ring_positions[1][0]], [ring_positions[0][1], ring_positions[1][1]], color = 'blue', lw = 3, zorder = 14) #Plot line connecting centres

        #Plot arrow for drifting direction
        if drift_distance > 0:
            #Find line mid-point coordinates
            mid_x = (ring_positions[0][0] + ring_positions[1][0]) / 2
            mid_y = (ring_positions[0][1] + ring_positions[1][1]) / 2
            
            #Find drift unit vector
            unit_x = (ring_positions[1][0] - ring_positions[0][0]) / drift_distance
            unit_y = (ring_positions[1][1] - ring_positions[0][1]) / drift_distance
            
            #Calculate arrow dimensions
            tip_x = mid_x + unit_x
            tip_y = mid_y + unit_y
            base_x = mid_x - unit_x
            base_y = mid_y - unit_y
            
            ax.annotate('', xy = (tip_x, tip_y), xytext = (base_x, base_y), arrowprops=dict(color = 'blue')) #Plot arrow

        ax.legend(line, [f'{drift_distance:.2f} px ({drift_speed:.2f} px/min)'], loc = 'lower right') #Add legend with drift information

        ax.scatter(roi_centre, roi_centre, color = 'purple', marker = '+', s = 100, linewidths = 2, zorder = 50) #Plot roi centre

        #Add display size labels
        ax.text(roi_centre, roi_centre - display_centre - 2, f"{display_roi:.0f}px", ha = 'center', va = 'top', fontsize = 12, fontweight = 'bold', color = 'black')
        ax.text(roi_centre - display_centre - 2, roi_centre, f"{display_roi:.0f}px", ha = 'center', va = 'center', fontsize = 12, fontweight = 'bold', color = 'black')

        #Display plot
        plt.tight_layout()
        plt.show()