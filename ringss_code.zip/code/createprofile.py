#Import libraries
import sys
import os
import subprocess
import re
from datetime import datetime, timezone

#Set paths
python = 'C:/Users/adamd/miniconda3/python.exe' #Absolute python.exe path
data_path = 'C:/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/data' #Absolute main data folder path

def create_singles(inputdir, outputdir, object_name):
    #Create all singles folders and subfolders
    os.makedirs(outputdir, exist_ok=True) #Create singles folder
    os.makedirs(outputdir + '/' + object_name + ' ((moments))', exist_ok=True) #Create singles moments subfolder
    os.makedirs(outputdir + '/' + object_name + ' ((previews))', exist_ok=True) #Create singles previews subfolder
    
    def order_key(inputdir):
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', inputdir)] #Splits string into parts of digits and non-digits
    
    dirs = [f for f in os.listdir(inputdir) if os.path.isdir(os.path.join(inputdir, f))] #Find all capture folders
        
    dirs.sort(key=order_key) #Order capture folders the same way windows file explorer does
    
    #Run cube2.py for all captures    
    for i, dir_name in enumerate(dirs):
        single_path = os.path.join(inputdir, dir_name) #Join input, capture
        
        subprocess.run([python, 'cube2.py', single_path, outputdir + '/' + object_name, str(i + 1)], text=True) #Run cube2.py, in singles mode

if __name__ == "__main__": #Check if python script is run directly
    if len(sys.argv) < 3: #Make sure correct inputs are given
        print('\033[91mError: Command should have format "python createprofile.py {object_name} {hr_number}"\033[0m') #Error (red) print
        sys.exit()
  
    #Extract target information from input
    object_name = sys.argv[1] #Get object name
    hr = sys.argv[2] #Get HR number
    
    #Take capture
    print('\033[94mTaking capture \033[95m(takecapture.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'takecapture.py', object_name, hr], text=True) #Takes capture (takecapture.py)
    
    #Extract normal path
    data_folder = os.path.relpath(os.path.abspath(data_path), os.path.abspath(os.path.dirname(__file__)))
    timestamp = datetime.now(timezone.utc) #Get current time in UTC+0
    date_folder = timestamp.strftime('%Y-%m-%d') #Extract date from timestamp
    time_folder = timestamp.strftime('%H-%M-%S') #Extract date from timestamp
    
    normalised_path = os.path.normpath(max((os.path.join(data_folder, date_folder, d) for d in os.listdir(os.path.join(data_folder, date_folder)) if os.path.isdir(os.path.join(data_folder, date_folder, d))), key=os.path.getmtime)) #Get latest capture
    
    #Extract date and object names
    path_parts = normalised_path.split(os.sep) #Split path into folders
    date_name = path_parts[-2] #Extract date name from path
    object_name = path_parts[-1] #Extract object name from path
    
    #Create main output path
    main_output_path = os.path.join(data_path, f'../outputs5/{date_name}/{object_name}') #Create date and object output path
    os.makedirs(main_output_path, exist_ok=True) #Create object output folder
    
    output_path = os.path.relpath(os.path.abspath(main_output_path), os.path.abspath(os.path.dirname(__file__))) #Find relative output path
    json_path = os.path.join(output_path, object_name + ' ((moments))') #Puts moments path together
    stm_path = os.path.join(output_path, object_name) #Puts stm path together
    weighted_parameters_path = os.path.join(data_path, f'../outputs5/{date_name}/Weighted Parameters/par-weights.json') #Get parameters path
    
    #Create stastical moments for each capture
    create_singles(normalised_path, output_path, object_name) #Create singles
    
    subprocess.run([python, 'createstm.py', json_path, 'auto4'], text=True) #Creates stm file (createstm.py)
    
    subprocess.run([python, 'readstm.py', weighted_parameters_path, stm_path], text=True) #Creates prof file (readstm.py)
    
    print('\033[92mTurbulence profile successfully restored\033[0m') #Success (green) print
    
    #Generate plots
    subprocess.run([python, 'plotaps.py', output_path, 'auto'], text=True) #Run aps extraction
    subprocess.run([python, 'plotprofile.py', output_path, 'auto'], text=True) #Run plot creation