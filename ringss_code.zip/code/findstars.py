import sys
import json
from astropy.coordinates import SkyCoord, EarthLocation, AltAz
from astropy.time import Time
from astropy import units as u
from astroquery.vizier import Vizier

#Assign site location and star catalouge
lat = -37.034194 #degrees | Site latitude
long = 174.985722 #degrees | Site longitude
catalouge_path = 'starcat.json' #Relative path to star catalouge

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print('\033[91mError: Command should have format "python findstars.py {min_zenith} {max_zenith}"\033[0m') #Error (red) print
        sys.exit()

    #Extract inputs
    min_zd = float(sys.argv[1]) #Minimum zentih angle range
    max_zd = float(sys.argv[2]) #Maximum zentih angle range

    #Read star catalouge
    star_catalouge = open(catalouge_path, 'r') #Open star catalouge
    star_data = json.load(star_catalouge) #Extra star data from catalouge

    hr_list = [int(hr) for hr in star_data.keys()] #Extract HR numbers from catalouge
    hr_str = ','.join(map(str, hr_list)) #Convert list of HR numbers to comma-separated string

    Vizier.ROW_LIMIT = -1 #Remove row limit (allows all results to be returned)
    catalouge = 'V/50' #Specify the bright star catalouge
    result = Vizier.query_constraints(catalog = catalouge, HR = hr_str) #Query the bright star catalouge

    if len(result) == 0:
        hr_coords = {} #Return empty dictionary
    else:
        table = result[0] #Extract first table from query result
        
        hr_coords = {} #Dictionary to hold coordinates
        
        for row in table:
            if row['Name'] != '': #Extract name (if exists)
                name = row['Name']
            else:
                name = 'Unknown'

            hr_coords[row['HR']] = (row['RAJ2000'], row['DEJ2000'], name) #Store RA, DEC, and name keyed by HR number

    time = Time.now() #Get current UTC time
    location = EarthLocation(lat = lat * u.deg, lon = long * u.deg) #Set observing location
    results = [] #List to hold results

    #Find stars within zenith range for current location and time
    for hr in hr_list:
        if hr not in hr_coords:
            continue

        ra, dec, name = hr_coords[hr] #Extract RA, DEC, and name
        star_coord = SkyCoord(ra = ra, dec = dec, unit = (u.hourangle, u.deg)) #Create SkyCoord object
        star_altaz = star_coord.transform_to(AltAz(obstime = time, location = location)) #Convert to Alt-Az

        altitude = star_altaz.alt.deg #Get altitude in degrees
        zd = 90 - altitude #Calculate zenith distance

        if min_zd <= zd <= max_zd and altitude > 0: #Check if star is within zenith range and above horizon
            brightness = float(star_data[str(hr)][2]) #Get magnitude from star catalog
            results.append((name, hr, zd, brightness)) #Append results

    results.sort(key = lambda x: x[3]) #Sort results by brightness

    if not results:
        print('\033[93mWarning: No stars found within {min_zd:.2f} and {max_zd:.2f}"\033[0m') #Warning (yellow) print
    else:
        for name, hr, zd, brightness in results:
            print(f'\033[96m{name} ({hr}): {brightness}, {zd:.2f}°\033[0m') #Smaller progress (light-blue) print