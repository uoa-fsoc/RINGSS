#Import libraries
import sys
import os
import subprocess
import shutil
import json
from datetime import datetime, timezone
import re

#Set paths
python = 'C:/Users/adamd/miniconda3/python.exe' #Absolute python.exe path
parameters_path = 'par-ardmore.json' #Relative parameters file path
data_path = 'C:/Users/adamd/Desktop/PHYSICS 789/RINGSS (local files)/Rings Processing/data' #Absolute main data folder path

if __name__ == "__main__": #Check if python script is run directly
    print('\033[94mStarting weight calculations \033[95m(createweights.py)\033[0m') #Progress (blue) print and script (purple) print
    
    if len(sys.argv) < 3: #Make sure correct inputs are given
        print('\033[91mError: Command should have format "python createweights.py {object_name} {hr_number}"\033[0m') #Error (red) print
        sys.exit()
    
    #Extract target information from input
    object_name = sys.argv[1] #Get object name
    hr = sys.argv[2] #Get HR number
    
    #Take capture to extract aberrations from
    print('\033[94mTaking capture \033[95m(takecapture.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'takecapture.py', object_name, hr, 'aber'], text=True) #Takes capture (takecapture.py)
    
    #Extract normal path
    data_folder = os.path.relpath(os.path.abspath(data_path), os.path.abspath(os.path.dirname(__file__)))
    timestamp = datetime.now(timezone.utc) #Get current time in UTC+0
    date_folder = timestamp.strftime('%Y-%m-%d') #Extract date from timestamp
    
    aberration_path = max((os.path.join(data_folder, date_folder, 'Aberrations', d) for d in os.listdir(os.path.join(data_folder, date_folder, 'Aberrations')) if os.path.isdir(os.path.join(data_folder, date_folder, 'Aberrations', d))), key=os.path.getmtime) #Get latest aberration capture
    
    normalised_path = os.path.normpath(aberration_path) #Nomarlised path
    path_parts = normalised_path.split(os.sep) #Split path into folders
    
    #Extract date and object names
    date_name = path_parts[-3] #Extract date name from path
    full_name = path_parts[-1] #Extract full name from path
    time_name = full_name.split(' ')[0] #Extract time name from path
    
    #Create main output path
    main_output_path = os.path.join(os.getcwd(), f'../outputs5/{date_name}/Weighted Parameters') #Create date and object output path
    os.makedirs(main_output_path, exist_ok=True) #Create object output folder
    
    output_path = os.path.relpath(os.path.abspath(main_output_path), os.path.abspath(os.path.dirname(__file__))) #Find relative output path
    captures_path = os.path.relpath(os.path.abspath(aberration_path), os.path.abspath(os.path.dirname(__file__)))
    cubes_path = os.path.join(output_path, full_name)
    stm_path = os.path.join(output_path, time_name) #Puts stm path together
    
    #Create stastical moments
    print('\033[94mCalculating statistical moments \033[95m(cube2.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'cube2.py', aberration_path, output_path], text=True) #Run cube2.py, in singles mode
    
    #Generate cubes for each capture
    os.makedirs(cubes_path, exist_ok=True) #Create singles folder
    os.makedirs(cubes_path + '/' + object_name + ' ((moments))', exist_ok=True) #Create singles moments subfolder
    os.makedirs(cubes_path + '/' + object_name + ' ((previews))', exist_ok=True) #Create singles previews subfolder
    
    def order_key(inputdir):
        return [int(text) if text.isdigit() else text.lower() for text in re.split(r'(\d+)', inputdir)] #Splits string into parts of digits and non-digits
    
    dirs = [f for f in os.listdir(captures_path) if os.path.isdir(os.path.join(captures_path, f))] #Find all capture folders
        
    dirs.sort(key=order_key) #Order capture folders the same way windows file explorer does
    
    for i, dir_name in enumerate(dirs):
        single_path = os.path.join(captures_path, dir_name) #Join input, capture
        
        subprocess.run([python, 'cube2.py', single_path, cubes_path + '/' + object_name, str(i + 1)], text=True) #Run cube2.py, in singles mode
    
    print('\033[94mAveraging stastical moments \033[95m(createstm.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'createstm.py', cubes_path + '/' + object_name + ' ((moments))', 'weights'], text=True) #Creates stm file (createstm.py)
    
    weighted_parameters_path = os.path.join(output_path, 'par-weights.json') #Puts parameters path together
    aberrations_path = os.path.join(output_path, 'aberrations.json') #Puts aberrations path together
    weights_path = os.path.join(output_path, 'weights.json') #Puts weights path together
    
    shutil.copy(parameters_path, weighted_parameters_path) #Copy parameters file
    
    weighted_parameters_file = open(weighted_parameters_path, 'r+') #Open new parameters file
    weighted_parameters = json.load(weighted_parameters_file) #Load new parameters file
    weighted_parameters["profrest"]["aber"] = aberrations_path #Edit aberrations file path
    weighted_parameters["profrest"]["weightfile"] = weights_path #Edit new weights file path
    
    #Save new parameters file
    weighted_parameters_file.seek(0)
    json.dump(weighted_parameters, weighted_parameters_file, indent=2)
    weighted_parameters_file.truncate()
    weighted_parameters_file.close()
    
    print('\033[94mComputing aberrations \033[95m(aberration.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'aberration.py', weighted_parameters_path], text=True) #Calculates aberrations
    
    print('\033[94mComputing aberration amplitudes \033[95m(aberstm.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'aberstm.py', weighted_parameters_path, os.path.splitext(stm_path)[0]], text=True) #Calculates aberration amplitudes
    
    print('\033[94mComputing weighting functions \033[95m(getweight5.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'getweight5.py', weighted_parameters_path], text=True) #Calculates weighting functions
    
    print('\033[94mPlotting weighting functions \033[95m(plotweights.py)\033[0m') #Progress (blue) print and script (purple) print
    subprocess.run([python, 'plotweights.py', weights_path, 'auto'], text=True) #Calculates weighting functions
    
    print('\033[92mWeights successfully calculated\033[0m') #Success (green) print