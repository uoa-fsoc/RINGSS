import numpy as np
import matplotlib.pyplot as plt
from scipy.special import j0

#Instrument parameters
D = 0.125 #m | Telescope aperture
epsilon = 0.5 #Central obscuration (by diameter)
lambdaa = 600e-9 #m | Wavelength
F = 0.381 #m | Focal length
p = 2.9e-6 #m | Pixel size
r = 12.3 #px | Optimal ring radius
target_rms_ratio = 0.1 #Optimal root means squared ratio (spherical/defocus)
see = 2.5 #arseconds | Expected seeing

#Compute aperature values
H = D * (1 + epsilon) * F / (4 * r * p) #Compute conjugation distance
R_out = D / 2 #Compute Outer pupil radius
R_in = epsilon * D / 2 #Compute inner pupil radius

#Setup sampling
r = np.linspace(R_in, R_out, 16000) #Radial array
rho = r / R_out #Normalized radius
dr = r[1] - r[0] #Radial step
w = r / np.sum(r) #Normalized radial weighting

theta_max = 40 * np.pi / (180 * 3600) #Set angular range of -40 to 40 arcseconds
theta = np.linspace(-theta_max, theta_max, 8000) #Angular coordinate array
k = 2 * np.pi / lambdaa #Calculate Wavenumber

#Compute defocus phase
phi_def = np.pi * r**2 / (lambdaa * H) #Find physical defocus phase
phi_def = phi_def - np.sum(phi_def * w) #Remove piston term
rms_def = np.sqrt(np.sum(phi_def**2 * w)) #Find defocus root means squared

#Compute spherical aberration
Z40 = 6 * rho**4 - 6 * rho**2 + 1 #Zernike spherical term
Z40 = Z40 - np.sum(Z40 * w) #Rremove piston term
rms_Z40 = np.sqrt(np.sum(Z40**2 * w)) #Find spherical aberration root means squared
c_mag = (target_rms_ratio * rms_def) / (rms_Z40 if rms_Z40 > 0 else 1.0) #Calculate scale factor

phi_sph_plus = c_mag * Z40 #Positive case
phi_sph_minus = -c_mag * Z40 #Negative case

#Find case with lower slope variance
dphi_dr_plus = np.gradient(phi_def + phi_sph_plus, r) #Compute derivative (positive case)
mu_plus = np.sum(dphi_dr_plus * w) #Get average slope (positive case)
var_plus = np.sum((dphi_dr_plus - mu_plus)**2 * w) #Get slope variance (positive case)

dphi_dr_minus = np.gradient(phi_def + phi_sph_minus, r) #Compute derivative (negative case)
mu_minus = np.sum(dphi_dr_minus * w) #Get average slope (negative case)
var_minus = np.sum((dphi_dr_minus - mu_minus)**2 * w) #Get slop variance (negative case)

if var_minus < var_plus: #Choose smaller slope variance
    phi_sph = phi_sph_minus
else:
    phi_sph = phi_sph_plus
    
phi_sph -= np.sum(phi_sph * w) #Remove piston term
rms_sph = np.sqrt(np.sum(phi_sph**2 * w)) #Find spherical aberration root means squared

#Generate conic wavefront
W_conic = np.exp(1j * (phi_def + phi_sph))

#Create turbulence phase
theta_rad = see * np.pi / (180 * 3600) #Convert seeing to radians
r0 = 0.98 * lambdaa / theta_rad #Calculate Fried parameter

np.random.seed(42) #Generate random seed (so can be easily reproduced)
N = len(r) #Set number of samples
kf = np.fft.rfftfreq(N, dr) #Make spatial frequency grid
kf[0] = 1e-10 #Avoid division by zero (instead use really small value)
PSD = 0.023 * r0**(-5/3) * kf**(-11/3) #Calculate 1D Kolmogorov power spectral density
cn = (np.random.randn(len(kf)) + 1j * np.random.randn(len(kf))) * np.sqrt(PSD / 2) #Make random spectrum
phi_turb = np.fft.irfft(cn, n=N) #Get turbulence phase
phi_turb -= np.sum(phi_turb * w) #Remove piston term
rms_turb = np.sqrt(np.sum(phi_turb**2 * w)) #Find turbulence root means squared
phi_turb *= (rms_def / rms_turb) * 0.1 if rms_turb > 0 else 0.0 #Apply ratio with defocus

#Generate turbulence wavefront
W_turb = np.exp(1j * (phi_def + phi_turb))

#Compute conic intensity profile
integrand_conic = r[:, None] * j0(k * r[:, None] * theta[None, :]) * W_conic[:, None] #Calculate integrand
A_conic = np.sum(integrand_conic, axis=0) * dr #Calculate amplitude
I_conic = np.abs(A_conic)**2 #Calculate intensity
I_conic /= I_conic.max() #Nomarlise profile

#Compute turbulence intensity profile
integrand_turb = r[:, None] * j0(k * r[:, None] * theta[None, :]) * W_turb[:, None] #Calculate integrand
A_turb = np.sum(integrand_turb, axis=0) * dr #Calculate amplitude
I_turb = np.abs(A_turb)**2 #Calculate intensity
I_turb /= I_turb.max() #Nomarlise profile

#Plot intensity profiles
theta_arcsec = theta * (180 * 3600 / np.pi) #Radians to arcseconds conversion
plt.figure(figsize = (10, 5)) #Set figure size
plt.plot(theta_arcsec * 4.848e-6 * (F / p), I_conic, label = 'Conic', color = 'royalblue') #Plot conic intensity
plt.plot(theta_arcsec * 4.848e-6 * (F / p), I_turb, label = 'Turbulence', color = 'darkmagenta') #Plot turbulent intensity
plt.xlabel("Radial Distance [pixels]") #Add x-axis label
plt.ylabel("Normalized intensity") #Add y-axis label
plt.xlim(-20, 20) #Limit view to 20 pixel radius
plt.xticks(np.arange(-20, 25, 5)) #Set x-ticks to every 5 pixels
plt.grid(True) #Add grid
plt.legend() #Add legend
plt.show() #Display plot