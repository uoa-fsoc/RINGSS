#Import libraries
from pathlib import Path
import re
import sys
import os
import numpy as np
import matplotlib.pyplot as plt
import json

#Optional settings
plot_individual_aps = True #Toggle plotting of individual capture APS plotting
plot_noise_aps = False #Toggle raw APS and noise level plotting
plot_finite_exposure_aps = False #Toggle noise-corrected, non-finite-exposure-corrected APS plotting

#Set paths
parameters_path = 'par-ardmore.json' #Relative parameters file path

def set_output_path(input_path):
    date_format = re.compile(r'^\d{4}-\d{2}-\d{2}$') #date folder name format
    
    for parent in [input_path] + list(input_path.parents): #Look through every folder of path
        if date_format.match(parent.name): #Look for matching format
            plots_folder = parent / "Angular Power Spectrum Plots" #Set plot path
            plots_folder.mkdir(exist_ok=True)  #Create path if doesn't exist
            
            return plots_folder
        
def plot_angular_power_spectrum(parameters, stm_path, save_plots):
    #Extract path details
    parent_folders = stm_path.parents #Divide path into parent folders
    time_name = parent_folders[1].name #Get time name
    sequence_name = parent_folders[0].name #Get sequence name
    stm_name = f'{time_name} - {sequence_name}.png' #Create profile name
    
    in_brackets = re.search(r'\((.*?)\)', time_name)
    
    if in_brackets:
        object_name = in_brackets.group(1) #Get object name
    
    stm = open(stm_path, 'r') #Open stm file
    
    #Extract information
    for line in stm: #Look through all lines
        data = line.split(',') #Split inputs on line
        
        if data[0] == 'O': #Check if information line
            gain = float(data[5]) #Gain | Electrons per ADU
    
    #Extract angular power spectrum
    angular_powers = [] #Initiate angular powers list
    angular_powers_avg = None #Initiate average angular powers
    #angular_powers_nocorr = None
    
    stm.seek(0) #Go back to start of file
    
    for line in stm: #Look through all lines
        data = line.split(',') #Split inputs on line

        if data[0] == 'm': #Check if individual line
            var = np.array(data[19:40], dtype = float) #Extract angular powers
            cov = np.array(data[40:61], dtype = float) #Extract covariances
            
            #Calculate angular powers noise
            #eladu = 3.60 * pow(10, -gain / 200)
            eladu = 0.3 #Our hardcoded for gain of 200
            noise_parameters = data[15:19]  #Noise parameters
            flux_adu = float(data[4]) #Flux in ADU
            flux = eladu * flux_adu  #Flux in electrons
            a_noise = float(noise_parameters[0]) / flux + float(noise_parameters[1]) * pow(parameters["telescope"]["ron"] / flux, 2)  #Angular powers noise
            
            #Apply corrections
            modes_count = parameters["profrest"]["mmax"] + 1 #Number of angular modes
            var1 = np.array(var[1:modes_count + 1], float) - a_noise #Subtract noise, no noise on total flux/m=0
            var1 *= (var1 > 0)  #Set negative values to zero
            cov1 = np.array(cov[1:modes_count + 1], float) #Trim covariances to match
            rho = cov1 / var1 #Correlation coefficient
            var_corr = var1 / (0.8 + 0.2 * rho) #Apply finite exposure time correction
            
            angular_powers.append(np.concatenate(([var[0]], var_corr))) #Append angular powers, and add m=0 back
            
        elif data[0] == 'M': #Check if average line
            var = np.array(data[20:41], dtype = float) #Extract angular powers
            cov = np.array(data[41:62], dtype = float) #Extract covariances
            
            #Calculate angular powers noise
            #eladu = 3.60 * pow(10, -gain / 200)
            eladu = 0.3 #Our hardcoded for gain of 200
            noise_parameters = data[16:20]  #Noise parameters
            flux_adu = float(data[5]) #Flux in ADU
            flux = eladu * flux_adu  #Flux in electrons
            a_noise = float(noise_parameters[0]) / flux + float(noise_parameters[1]) * pow(parameters["telescope"]["ron"] / flux, 2)  #Angular powers noise
            
            #Apply corrections
            var1 = np.array(var[1:modes_count + 1], float) - a_noise #Subtract noise, no noise on total flux/m=0
            var1 *= (var1 > 0)  #Set negative values to zero
            cov1 = np.array(cov[1:modes_count + 1], float) #Trim covariances to match
            rho = cov1 / var1 #Correlation coefficient
            var_corr = var1 / (0.8 + 0.2 * rho) #Apply finite exposure time correction
            
            angular_powers_avg = np.concatenate(([var[0]], var_corr)) #Set final average angular powers, and add m=0 back
            angular_powers_nocorr = np.concatenate(([var[0]], var1)) #Set average angular power spectrum without finite-exposure correction
            angular_powers_noise = np.array(var[0:modes_count + 1], float) #Set average angular power spectrum without noise correction
            
    stm.close() #Close stm file
            
    angular_modes = np.array(list(range(modes_count))) #Set angular modes
    
    #Plot angular power spectrum
    plt.figure(figsize = (10, 6)) #Adjust plot size
    
    if plot_individual_aps == True:
        for angular_power in angular_powers: #Plot all individual angular power spectrums
            plt.plot(angular_modes, angular_power, marker = 'o', linestyle = '-', markersize = 6, linewidth = 3, color = 'grey', alpha = 0.2) #Plot indiviudal angular power spectrum
            
    plt.plot(angular_modes, angular_powers_avg, marker = 'o', linestyle = '-', markersize = 6, linewidth = 3, color = 'MediumSlateBlue', label = 'Fully-corrected APS') #Plot final average angular power spectrum
    
    if plot_finite_exposure_aps == True:
        plt.plot(angular_modes, angular_powers_nocorr, marker = 'o', linestyle = '-', markersize = 6, linewidth = 3, color = 'green', label = 'Noise-corrected APS') #Plot average angular power spectrum without finite-exposure correction
        
    if plot_noise_aps == True:
        plt.plot(angular_modes, angular_powers_noise, marker = 'o', linestyle = '-', markersize = 6, linewidth = 3, color = 'orange', label = 'Raw APS') #Plot average angular power spectrum without noise correction
        plt.axhline(a_noise, linestyle = '-', linewidth = 3, color='red', label = 'Noise Level') #Plot noise level
        
    if plot_finite_exposure_aps == True or plot_noise_aps == True:
        plt.legend(frameon = False, fontsize = 14, loc = 'upper right') #Display legend
    
    plt.yscale('log') #Set y-axis to log-scale
    plt.tick_params(axis = 'both', which = 'major', labelsize = 10) #Set ticks fontsize
    plt.xticks(angular_modes) #Set ticks on x axis to every value
    plt.xlabel('Angular Mode [m]', fontsize = 16) #Set x-axis label
    plt.ylabel('Angular Power ($\\langle |a_m|^2 \\rangle$)', fontsize = 16) #Set y-axis label
    
    #Save or display plot, based on call
    if save_plots == True: #Check if coming from maintaincapture5.py
        aps_path = output_path / stm_name #Set profile path
        plt.savefig(aps_path, bbox_inches = 'tight') #Save plot (removing extra white-space)
        plt.close() #Close plot
    else:
        plt.tight_layout() #Remove extra white-space
        plt.show() #Display plot

if __name__ == "__main__": #Check if python script is run directly
    if len(sys.argv) < 2: #Make sure correct inputs are given
        print('\033[91mError: Command should have format "python plotaps.py {any_output_path}"\033[0m') #Error (red) print
        sys.exit()
        
    if len(sys.argv) > 2 and sys.argv[2].lower() == 'auto': #Check if coming from maintaincapture5.py
        save_plots = True
    else:
        save_plots = False
  
    #Extract files and set paths
    input_path = Path(os.path.relpath(os.path.abspath(sys.argv[1]), os.path.abspath(os.path.dirname(__file__)))) #Find relative path
    output_path = set_output_path(input_path) #Create plot output path
    stm_paths = [p for p in input_path.rglob('*.stm') if 'Weighted Parameters' not in str(p)] #Find all stm paths, excluding aberrations one
    
    #Extract parameters
    parameters_file = open(parameters_path, 'r') #Open parameters file
    parameters = json.load(parameters_file) #Load parameters
    parameters_file.close() #Close parameters file
    
    #Plot all angular power spectrums
    for stm_path in stm_paths:
        plot_angular_power_spectrum(parameters, stm_path, save_plots)
        
    plt.close('all') #Make sure all scripts are closed
    print('\033[92mAll angular power spectrums succesful plotted\033[0m') #Success (green) print